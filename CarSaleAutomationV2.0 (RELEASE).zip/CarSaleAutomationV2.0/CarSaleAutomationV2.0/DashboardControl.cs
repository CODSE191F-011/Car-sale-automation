﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LiveCharts;
using LiveCharts.Wpf;
using System.Data.SqlClient;

namespace CarSaleAutomationV2._0
{
    public partial class DashboardControl : UserControl
    {
        public DashboardControl()
        {
            InitializeComponent();
        }
        Database db = new Database();

        private void DashboardControl_Load(object sender, EventArgs e)
        {
            using (CarSaleAutomationEntities db = new CarSaleAutomationEntities())
            {
                var data = db.YearlySales();
                LineSeries line = new LineSeries()
                { DataLabels = true, Values = new ChartValues<int>(), LabelPoint = point => point.Y.ToString() };
                Axis ax = new Axis() { Separator = new Separator() { Step = 1, IsEnabled = false } };
                ax.Labels = new List<string>();
                foreach (var x in data)
                {
                    line.Values.Add(x.Total.Value);
                    ax.Labels.Add(x.Year.ToString());
                }
                CartesianChartYearly.Series.Add(line);
                CartesianChartYearly.AxisX.Add(ax);
                CartesianChartYearly.AxisY.Add(new Axis { LabelFormatter = value => value.ToString(), Separator = new Separator() { StrokeThickness = 0 } });
            }
            using (CarSaleAutomationEntities1 db = new CarSaleAutomationEntities1())
            {
                var data = db.MonthlySales();
                LineSeries line = new LineSeries()
                { DataLabels = true, Values = new ChartValues<int>(), LabelPoint = point => point.Y.ToString() };
                Axis ax = new Axis() { Separator = new Separator() { Step = 1, IsEnabled = false } };
                ax.Labels = new List<string>();
                foreach (var x in data)
                {
                    line.Values.Add(x.Total.Value);
                    ax.Labels.Add(x.Month.ToString());
                }

                CartesianChartMonthly.Series.Add(line);
                CartesianChartMonthly.AxisX.Add(ax);
                CartesianChartMonthly.AxisY.Add(new Axis { LabelFormatter = value => value.ToString(), Separator = new Separator() { StrokeThickness = 0 } });
            }
            CartesianChartYearly.Visible = false;
            CartesianChartMonthly.Visible = true;
            ExpensesChart.Visible = false;
            LabelOnPie1.Visible = true;
            LabelOnPie2.Visible = true;
        }

        private void cmbbx_Type_onItemSelected(object sender, EventArgs e)
        {
            if (cmbbx_Type.selectedIndex == 0)
            {
                CartesianChartMonthly.Visible = false;
                CartesianChartYearly.Visible = true;
            }
            else if (cmbbx_Type.selectedIndex == 1)
            {
                CartesianChartYearly.Visible = false;
                CartesianChartMonthly.Visible = true;
            }
        }

        private void btn_View_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT * FROM Expenses WHERE Year = {cmbbx_Year.selectedValue} AND MONTH = {cmbbx_Month.selectedIndex+1}";
                SqlDataReader reader = db.ReadData(query);
                if (reader.HasRows)
                {
                    LabelOnPie1.Visible = false;
                    LabelOnPie2.Visible = false;
                    ExpensesChart.Visible = true;
                    Func<ChartPoint, string> labelpoint = chartpoint => string.Format("{0} ({1:p})", chartpoint.Y, chartpoint.Participation);

                    ExpensesChart.Series = new SeriesCollection
                    {
                        new PieSeries
                        {
                            Title = "Telephone",
                            Values = new ChartValues<double> { Convert.ToDouble(reader[3])},
                            PushOut = 15,
                            DataLabels = true,
                        },
                        new PieSeries
                        {
                            Title = "Water",
                            Values = new ChartValues<double> {Convert.ToDouble(reader[4])},
                            DataLabels = true,
                        },
                        new PieSeries
                        {
                            Title = "Electricity",
                            Values = new ChartValues<double> {Convert.ToDouble(reader[5])},
                            DataLabels = true,
                        },
                        new PieSeries
                        {
                            Title = "Cleaning",
                            Values = new ChartValues<double> {Convert.ToDouble(reader[6])},
                            DataLabels = true,
                        },
                        new PieSeries
                        {
                            Title = "Others",
                            Values = new ChartValues<double> {Convert.ToDouble(reader[7])},
                            DataLabels = true,
                        }
                    };
                    ExpensesChart.LegendLocation = LegendLocation.Bottom;
                    db.CloseConnection();
                }
                else
                {
                    ExpensesChart.Visible = false;
                    LabelOnPie1.Visible = true;
                    LabelOnPie2.Visible = true;
                    MessageBox.Show("No data","Car Sale Automation",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    db.CloseConnection();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please restart the app","Car Sale Automation",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                db.CloseConnection();
            }
        }
    }
}
