﻿namespace CarSaleAutomationV2._0
{
    partial class VehicleControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VehicleControl));
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Index = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Color = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_Model = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_Company = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_ChassisNo = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Meter = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Price = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_SearchModel = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtbx_SearchColor = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_Update = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Clear = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Remove = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Add = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Browse = new Bunifu.Framework.UI.BunifuThinButton2();
            this.VehicleImage = new System.Windows.Forms.PictureBox();
            this.btn_Search = new Bunifu.Framework.UI.BunifuThinButton2();
            this.DefaultImage = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.VehicleImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DefaultImage)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(3, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(131, 34);
            this.bunifuCustomLabel1.TabIndex = 1;
            this.bunifuCustomLabel1.Text = "Vehicles";
            // 
            // txtbx_Index
            // 
            this.txtbx_Index.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Index.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Index.ForeColor = System.Drawing.Color.White;
            this.txtbx_Index.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Index.HintText = "";
            this.txtbx_Index.isPassword = false;
            this.txtbx_Index.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Index.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Index.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Index.LineThickness = 3;
            this.txtbx_Index.Location = new System.Drawing.Point(324, 161);
            this.txtbx_Index.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Index.Name = "txtbx_Index";
            this.txtbx_Index.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Index.TabIndex = 33;
            this.txtbx_Index.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(140, 178);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(105, 27);
            this.bunifuCustomLabel8.TabIndex = 32;
            this.bunifuCustomLabel8.Text = "Vehicle Id";
            // 
            // txtbx_Color
            // 
            this.txtbx_Color.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Color.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Color.ForeColor = System.Drawing.Color.White;
            this.txtbx_Color.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Color.HintText = "";
            this.txtbx_Color.isPassword = false;
            this.txtbx_Color.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Color.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Color.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Color.LineThickness = 3;
            this.txtbx_Color.Location = new System.Drawing.Point(324, 317);
            this.txtbx_Color.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Color.Name = "txtbx_Color";
            this.txtbx_Color.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Color.TabIndex = 31;
            this.txtbx_Color.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_Model
            // 
            this.txtbx_Model.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Model.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Model.ForeColor = System.Drawing.Color.White;
            this.txtbx_Model.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Model.HintText = "";
            this.txtbx_Model.isPassword = false;
            this.txtbx_Model.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Model.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Model.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Model.LineThickness = 3;
            this.txtbx_Model.Location = new System.Drawing.Point(324, 265);
            this.txtbx_Model.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Model.Name = "txtbx_Model";
            this.txtbx_Model.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Model.TabIndex = 30;
            this.txtbx_Model.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_Company
            // 
            this.txtbx_Company.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Company.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Company.ForeColor = System.Drawing.Color.White;
            this.txtbx_Company.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Company.HintText = "";
            this.txtbx_Company.isPassword = false;
            this.txtbx_Company.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Company.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Company.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Company.LineThickness = 3;
            this.txtbx_Company.Location = new System.Drawing.Point(324, 213);
            this.txtbx_Company.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Company.Name = "txtbx_Company";
            this.txtbx_Company.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Company.TabIndex = 29;
            this.txtbx_Company.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(140, 334);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(64, 27);
            this.bunifuCustomLabel4.TabIndex = 28;
            this.bunifuCustomLabel4.Text = "Color";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(140, 282);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(74, 27);
            this.bunifuCustomLabel3.TabIndex = 27;
            this.bunifuCustomLabel3.Text = "Model";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(139, 230);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(104, 27);
            this.bunifuCustomLabel2.TabIndex = 26;
            this.bunifuCustomLabel2.Text = "Company";
            // 
            // txtbx_ChassisNo
            // 
            this.txtbx_ChassisNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_ChassisNo.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_ChassisNo.ForeColor = System.Drawing.Color.White;
            this.txtbx_ChassisNo.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_ChassisNo.HintText = "";
            this.txtbx_ChassisNo.isPassword = false;
            this.txtbx_ChassisNo.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_ChassisNo.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_ChassisNo.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_ChassisNo.LineThickness = 3;
            this.txtbx_ChassisNo.Location = new System.Drawing.Point(324, 369);
            this.txtbx_ChassisNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_ChassisNo.Name = "txtbx_ChassisNo";
            this.txtbx_ChassisNo.Size = new System.Drawing.Size(289, 44);
            this.txtbx_ChassisNo.TabIndex = 37;
            this.txtbx_ChassisNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(140, 386);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(115, 27);
            this.bunifuCustomLabel5.TabIndex = 36;
            this.bunifuCustomLabel5.Text = "Chassis No";
            // 
            // txtbx_Meter
            // 
            this.txtbx_Meter.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Meter.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Meter.ForeColor = System.Drawing.Color.White;
            this.txtbx_Meter.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Meter.HintText = "km";
            this.txtbx_Meter.isPassword = false;
            this.txtbx_Meter.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Meter.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Meter.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Meter.LineThickness = 3;
            this.txtbx_Meter.Location = new System.Drawing.Point(324, 421);
            this.txtbx_Meter.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Meter.Name = "txtbx_Meter";
            this.txtbx_Meter.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Meter.TabIndex = 39;
            this.txtbx_Meter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(140, 438);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(69, 27);
            this.bunifuCustomLabel6.TabIndex = 38;
            this.bunifuCustomLabel6.Text = "Meter";
            // 
            // txtbx_Price
            // 
            this.txtbx_Price.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Price.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Price.ForeColor = System.Drawing.Color.White;
            this.txtbx_Price.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Price.HintText = "lkr";
            this.txtbx_Price.isPassword = false;
            this.txtbx_Price.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Price.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Price.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Price.LineThickness = 3;
            this.txtbx_Price.Location = new System.Drawing.Point(324, 473);
            this.txtbx_Price.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Price.Name = "txtbx_Price";
            this.txtbx_Price.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Price.TabIndex = 41;
            this.txtbx_Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(140, 490);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(58, 27);
            this.bunifuCustomLabel7.TabIndex = 40;
            this.bunifuCustomLabel7.Text = "Price";
            // 
            // txtbx_SearchModel
            // 
            this.txtbx_SearchModel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_SearchModel.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_SearchModel.ForeColor = System.Drawing.Color.White;
            this.txtbx_SearchModel.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_SearchModel.HintText = "model";
            this.txtbx_SearchModel.isPassword = false;
            this.txtbx_SearchModel.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_SearchModel.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_SearchModel.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_SearchModel.LineThickness = 3;
            this.txtbx_SearchModel.Location = new System.Drawing.Point(91, 74);
            this.txtbx_SearchModel.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_SearchModel.Name = "txtbx_SearchModel";
            this.txtbx_SearchModel.Size = new System.Drawing.Size(154, 44);
            this.txtbx_SearchModel.TabIndex = 42;
            this.txtbx_SearchModel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // txtbx_SearchColor
            // 
            this.txtbx_SearchColor.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_SearchColor.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_SearchColor.ForeColor = System.Drawing.Color.White;
            this.txtbx_SearchColor.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_SearchColor.HintText = "color";
            this.txtbx_SearchColor.isPassword = false;
            this.txtbx_SearchColor.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_SearchColor.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_SearchColor.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_SearchColor.LineThickness = 3;
            this.txtbx_SearchColor.Location = new System.Drawing.Point(253, 74);
            this.txtbx_SearchColor.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_SearchColor.Name = "txtbx_SearchColor";
            this.txtbx_SearchColor.Size = new System.Drawing.Size(154, 44);
            this.txtbx_SearchColor.TabIndex = 49;
            this.txtbx_SearchColor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Update
            // 
            this.btn_Update.ActiveBorderThickness = 1;
            this.btn_Update.ActiveCornerRadius = 20;
            this.btn_Update.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Update.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Update.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Update.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Update.BackgroundImage")));
            this.btn_Update.ButtonText = "Update";
            this.btn_Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Update.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.IdleBorderThickness = 1;
            this.btn_Update.IdleCornerRadius = 20;
            this.btn_Update.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Update.IdleForecolor = System.Drawing.Color.White;
            this.btn_Update.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Update.Location = new System.Drawing.Point(797, 438);
            this.btn_Update.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(116, 37);
            this.btn_Update.TabIndex = 48;
            this.btn_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.ActiveBorderThickness = 1;
            this.btn_Clear.ActiveCornerRadius = 20;
            this.btn_Clear.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Clear.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Clear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Clear.BackgroundImage")));
            this.btn_Clear.ButtonText = "Clear";
            this.btn_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Clear.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.Color.White;
            this.btn_Clear.IdleBorderThickness = 1;
            this.btn_Clear.IdleCornerRadius = 20;
            this.btn_Clear.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Clear.IdleForecolor = System.Drawing.Color.White;
            this.btn_Clear.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.Location = new System.Drawing.Point(797, 485);
            this.btn_Clear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(116, 37);
            this.btn_Clear.TabIndex = 47;
            this.btn_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Remove
            // 
            this.btn_Remove.ActiveBorderThickness = 1;
            this.btn_Remove.ActiveCornerRadius = 20;
            this.btn_Remove.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Remove.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Remove.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Remove.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Remove.BackgroundImage")));
            this.btn_Remove.ButtonText = "Remove";
            this.btn_Remove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Remove.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Remove.ForeColor = System.Drawing.Color.White;
            this.btn_Remove.IdleBorderThickness = 1;
            this.btn_Remove.IdleCornerRadius = 20;
            this.btn_Remove.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Remove.IdleForecolor = System.Drawing.Color.White;
            this.btn_Remove.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Remove.Location = new System.Drawing.Point(675, 485);
            this.btn_Remove.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(116, 37);
            this.btn_Remove.TabIndex = 46;
            this.btn_Remove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.ActiveBorderThickness = 1;
            this.btn_Add.ActiveCornerRadius = 20;
            this.btn_Add.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Add.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Add.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Add.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Add.BackgroundImage")));
            this.btn_Add.ButtonText = "Add";
            this.btn_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Add.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.ForeColor = System.Drawing.Color.White;
            this.btn_Add.IdleBorderThickness = 1;
            this.btn_Add.IdleCornerRadius = 20;
            this.btn_Add.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Add.IdleForecolor = System.Drawing.Color.White;
            this.btn_Add.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Add.Location = new System.Drawing.Point(675, 438);
            this.btn_Add.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(116, 37);
            this.btn_Add.TabIndex = 45;
            this.btn_Add.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Browse
            // 
            this.btn_Browse.ActiveBorderThickness = 1;
            this.btn_Browse.ActiveCornerRadius = 20;
            this.btn_Browse.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Browse.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Browse.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Browse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Browse.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Browse.BackgroundImage")));
            this.btn_Browse.ButtonText = "Browse";
            this.btn_Browse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Browse.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse.ForeColor = System.Drawing.Color.White;
            this.btn_Browse.IdleBorderThickness = 1;
            this.btn_Browse.IdleCornerRadius = 20;
            this.btn_Browse.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Browse.IdleForecolor = System.Drawing.Color.White;
            this.btn_Browse.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Browse.Location = new System.Drawing.Point(678, 369);
            this.btn_Browse.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Browse.Name = "btn_Browse";
            this.btn_Browse.Size = new System.Drawing.Size(235, 37);
            this.btn_Browse.TabIndex = 44;
            this.btn_Browse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Browse.Click += new System.EventHandler(this.btn_Browse_Click);
            // 
            // VehicleImage
            // 
            this.VehicleImage.Image = global::CarSaleAutomationV2._0.Properties.Resources.Car;
            this.VehicleImage.Location = new System.Drawing.Point(678, 134);
            this.VehicleImage.Name = "VehicleImage";
            this.VehicleImage.Size = new System.Drawing.Size(235, 227);
            this.VehicleImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.VehicleImage.TabIndex = 43;
            this.VehicleImage.TabStop = false;
            // 
            // btn_Search
            // 
            this.btn_Search.ActiveBorderThickness = 1;
            this.btn_Search.ActiveCornerRadius = 20;
            this.btn_Search.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Search.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Search.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Search.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Search.BackgroundImage")));
            this.btn_Search.ButtonText = "Search";
            this.btn_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Search.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.White;
            this.btn_Search.IdleBorderThickness = 1;
            this.btn_Search.IdleCornerRadius = 20;
            this.btn_Search.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Search.IdleForecolor = System.Drawing.Color.White;
            this.btn_Search.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Search.Location = new System.Drawing.Point(420, 81);
            this.btn_Search.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(116, 37);
            this.btn_Search.TabIndex = 35;
            this.btn_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // DefaultImage
            // 
            this.DefaultImage.Image = global::CarSaleAutomationV2._0.Properties.Resources.Car;
            this.DefaultImage.Location = new System.Drawing.Point(678, 134);
            this.DefaultImage.Name = "DefaultImage";
            this.DefaultImage.Size = new System.Drawing.Size(235, 227);
            this.DefaultImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DefaultImage.TabIndex = 50;
            this.DefaultImage.TabStop = false;
            // 
            // VehicleControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.DefaultImage);
            this.Controls.Add(this.txtbx_SearchColor);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.btn_Browse);
            this.Controls.Add(this.VehicleImage);
            this.Controls.Add(this.txtbx_SearchModel);
            this.Controls.Add(this.txtbx_Price);
            this.Controls.Add(this.bunifuCustomLabel7);
            this.Controls.Add(this.txtbx_Meter);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Controls.Add(this.txtbx_ChassisNo);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.txtbx_Index);
            this.Controls.Add(this.bunifuCustomLabel8);
            this.Controls.Add(this.txtbx_Color);
            this.Controls.Add(this.txtbx_Model);
            this.Controls.Add(this.txtbx_Company);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Name = "VehicleControl";
            this.Size = new System.Drawing.Size(1027, 589);
            this.Load += new System.EventHandler(this.VehicleControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.VehicleImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DefaultImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Search;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Index;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Color;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Model;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Company;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_ChassisNo;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Meter;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Price;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_SearchModel;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.PictureBox VehicleImage;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Browse;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Update;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Clear;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Remove;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Add;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_SearchColor;
        private System.Windows.Forms.PictureBox DefaultImage;
    }
}
