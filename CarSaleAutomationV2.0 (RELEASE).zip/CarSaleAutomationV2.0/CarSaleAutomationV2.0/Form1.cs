﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSaleAutomationV2._0
{
    public partial class Form1 : Form
    {
        Database db = new Database();
        public Form1()
        {
            InitializeComponent();
        }

        Point lastPoint;

        private void TopPanel_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void TopPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            String query = "TRUNCATE TABLE LoggedInUser";
            db.Save_Update_Delete(query);
            this.Close();
        }

        private void btn_Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btn_ListView_Click(object sender, EventArgs e)
        {
            if (LeftPanel.Width == 50)
            {
                LeftPanel.Visible = false;
                LeftPanel.Width = 220;
                LeftPanelSlide.ShowSync(LeftPanel);
            }
            else
            {
                LeftPanel.Visible = false;
                LeftPanel.Width = 50;
                LeftPanelSlide.ShowSync(LeftPanel);
            }
        }

        private void btn_Dashboard_Click(object sender, EventArgs e)
        {
            SalesControl.Visible = false;
            CustomerControl.Visible = false;
            VehicleControl.Visible = false;
            UsersControl.Visible = false;
            PurchaseControl.Visible = false;
            ExpensesControl.Visible = false;
            LeftPanel.Visible = false;
            LeftPanel.Width = 50;
            LeftPanelSlide.ShowSync(LeftPanel);
            DashboardControlTransition.ShowSync(DashboardControl);
            DashboardControl.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CustomerControl.Visible = false;
            VehicleControl.Visible = false;
            UsersControl.Visible = false;
            PurchaseControl.Visible = false;
            ExpensesControl.Visible = false;
            SalesControl.Visible = false;
        }

        private void btn_Customers_Click(object sender, EventArgs e)
        {
            SalesControl.Visible = false;
            DashboardControl.Visible = false;
            VehicleControl.Visible = false;
            ExpensesControl.Visible = false;
            UsersControl.Visible = false;
            PurchaseControl.Visible = false;
            LeftPanel.Visible = false;
            LeftPanel.Width = 50;
            LeftPanelSlide.ShowSync(LeftPanel);
            CustomerControlTransition.ShowSync(CustomerControl);
            CustomerControl.Visible = true;
        }

        private void btn_Vehicles_Click(object sender, EventArgs e)
        {
            SalesControl.Visible = false;
            DashboardControl.Visible = false;
            CustomerControl.Visible = false;
            ExpensesControl.Visible = false;
            UsersControl.Visible = false;
            PurchaseControl.Visible = false;
            LeftPanel.Visible = false;
            LeftPanel.Width = 50;
            LeftPanelSlide.ShowSync(LeftPanel);
            VehicleControlTransition.ShowSync(VehicleControl);
            VehicleControl.Visible = true;
        }

        private void btn_Users_Click(object sender, EventArgs e)
        {
            SalesControl.Visible = false;
            DashboardControl.Visible = false;
            CustomerControl.Visible = false;
            VehicleControl.Visible = false;
            LeftPanel.Visible = false;
            ExpensesControl.Visible = false;
            PurchaseControl.Visible = false;
            LeftPanel.Width = 50;
            LeftPanelSlide.ShowSync(LeftPanel);
            UsersControlTransition.ShowSync(UsersControl);
            UsersControl.Visible = true;
        }

        private void btn_Purchase_Click(object sender, EventArgs e)
        {
            SalesControl.Visible = false;
            DashboardControl.Visible = false;
            CustomerControl.Visible = false;
            VehicleControl.Visible = false;
            UsersControl.Visible = false;
            LeftPanel.Visible = false;
            ExpensesControl.Visible = false;
            LeftPanel.Width = 50;
            LeftPanelSlide.ShowSync(LeftPanel);
            PurchaseControlTransition.ShowSync(PurchaseControl);
            PurchaseControl.Visible = true;
        }

        private void btn_Expenses_Click(object sender, EventArgs e)
        {
            SalesControl.Visible = false;
            DashboardControl.Visible = false;
            CustomerControl.Visible = false;
            VehicleControl.Visible = false;
            UsersControl.Visible = false;
            PurchaseControl.Visible = false;
            LeftPanel.Visible = false;
            ExpensesControl.Visible = false;
            LeftPanel.Width = 50;
            LeftPanelSlide.ShowSync(LeftPanel);
            ExpensesControlTransition.ShowSync(ExpensesControl);
            ExpensesControl.Visible = true;
        }

        private void btn_Sales_Click(object sender, EventArgs e)
        {
            CustomerControl.Visible = false;
            VehicleControl.Visible = false;
            UsersControl.Visible = false;
            PurchaseControl.Visible = false;
            ExpensesControl.Visible = false;
            DashboardControl.Visible = false;
            LeftPanel.Visible = false;
            LeftPanel.Width = 50;
            LeftPanelSlide.ShowSync(LeftPanel);
            SalesControlTransition.ShowSync(SalesControl);
            SalesControl.Visible = true;
        }
    }
}
