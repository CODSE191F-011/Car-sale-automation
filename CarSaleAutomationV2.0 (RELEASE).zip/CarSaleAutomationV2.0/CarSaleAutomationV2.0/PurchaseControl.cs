﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSaleAutomationV2._0
{
    public partial class PurchaseControl : UserControl
    {
        Database db = new Database();
        string vehicleId,company, model, color, chassisno;
        int meter;
        double price;

        private void btn_ClearCart_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "TRUNCATE TABLE Cart";
                int i = db.Save_Update_Delete(query);
                if (i == -1)
                {
                    string query2 = $"SELECT VehicleId,Company,Model,Color,ChassisNo,Meter,Price FROM Cart";
                    DataGridCart.DataSource = db.GetData(query2);
                }
                else
                {
                    MessageBox.Show("Failed to clear cart", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_AddToCart_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"INSERT INTO Cart VALUES ('{vehicleId}','{company}','{model}','{color}','{chassisno}','{meter}','{price}')";
                int i = db.Save_Update_Delete(query);
                if (i == 1)
                {
                    string query2 = $"SELECT * FROM Cart";
                    DataGridCart.DataSource = db.GetData(query2);
                }
                else
                {
                    MessageBox.Show("Error", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_Purchase_Click(object sender, EventArgs e)
        {
            try
            {
                string currentUser = db.GetLoggedInUser();
                string query2 = $"SELECT * FROM Customers WHERE CustomerId = '{txtbx_CustomerId.Text}'";
                SqlDataReader reader = db.ReadData(query2);
                if (reader.HasRows)
                {
                    db.CloseConnection();
                    string query = $"INSERT INTO Sales VALUES ('{txtbx_CustomerId.Text}','{vehicleId}','{cmbbx_Year.selectedValue}','{cmbbx_Month.selectedIndex +1}','{currentUser}')";
                    int i = db.Save_Update_Delete(query);
                    if (i == 1)
                    {
                        MessageBox.Show("You Purchased the vehicle", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtbx_CustomerId.Text = "";
                        txtbx_Search.Text = "";
                        db.CloseConnection();
                    }
                    else
                    {
                        MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        db.CloseConnection();
                    }
                }
                else
                {
                    MessageBox.Show("Customer doesn't exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    db.CloseConnection();
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                db.CloseConnection();
            }
            catch (Exception)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                db.CloseConnection();
            }
        }

        private void txtbx_Search_OnValueChanged(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT VehicleId,Company,Model,Color,ChassisNo,Meter,Price FROM Vehicles WHERE Model LIKE '{txtbx_Search.Text}%' OR Company LIKE '{txtbx_Search.Text}%'";
                DataGridVehicles.DataSource = db.GetData(query);
            }
            catch (SqlException)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public PurchaseControl()
        {
            InitializeComponent();
        }

        private void PurchaseControl_Load(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT VehicleId,Company,Model,Color,ChassisNo,Meter,Price FROM Vehicles";
                string query2 = $"Select * FROM Cart";
                DataGridVehicles.DataSource = db.GetData(query);
                DataGridCart.DataSource = db.GetData(query2);
            }
            catch (SqlException)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception)
            {
                MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DataGridVehicles_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                int rowIndex = e.RowIndex;
                //vehicleId = DataGridVehicles.Rows[rowIndex].Cells[0].Value.ToString();
                vehicleId = DataGridVehicles.Rows[rowIndex].Cells[0].Value.ToString();
                company = DataGridVehicles.Rows[rowIndex].Cells[1].Value.ToString();
                model = DataGridVehicles.Rows[rowIndex].Cells[2].Value.ToString();
                color = DataGridVehicles.Rows[rowIndex].Cells[3].Value.ToString();
                chassisno = DataGridVehicles.Rows[rowIndex].Cells[4].Value.ToString();
                meter = Convert.ToInt32(DataGridVehicles.Rows[rowIndex].Cells[5].Value);
                price = Convert.ToDouble(DataGridVehicles.Rows[rowIndex].Cells[6].Value);
            }
            catch (InvalidCastException)
            {
                MessageBox.Show("Empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("No data to select", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
