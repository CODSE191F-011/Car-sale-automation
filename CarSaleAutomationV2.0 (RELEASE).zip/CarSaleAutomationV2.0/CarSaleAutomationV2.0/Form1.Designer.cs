﻿namespace CarSaleAutomationV2._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation19 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation18 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation21 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation20 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation23 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation22 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation24 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation17 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TopPanel = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btn_Close = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_Minimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.LeftPanel = new System.Windows.Forms.Panel();
            this.btn_Sales = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_ListView = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_Users = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Dashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Expenses = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Customers = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Purchase = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Vehicles = new Bunifu.Framework.UI.BunifuFlatButton();
            this.LeftPanelSlide = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.RIghtPanel = new System.Windows.Forms.Panel();
            this.SalesControl = new CarSaleAutomationV2._0.SalesControl();
            this.DashboardControl = new CarSaleAutomationV2._0.DashboardControl();
            this.ExpensesControl = new CarSaleAutomationV2._0.ExpensesControl();
            this.PurchaseControl = new CarSaleAutomationV2._0.PurchaseControl();
            this.UsersControl = new CarSaleAutomationV2._0.UsersControl();
            this.VehicleControl = new CarSaleAutomationV2._0.VehicleControl();
            this.CustomerControl = new CarSaleAutomationV2._0.CustomerControl();
            this.CustomerControlTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.VehicleControlTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.UsersControlTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.PurchaseControlTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.ExpensesControlTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.DashboardControlTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.SalesControlTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.TopPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Minimize)).BeginInit();
            this.LeftPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_ListView)).BeginInit();
            this.RIghtPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // TopPanel
            // 
            this.TopPanel.BackColor = System.Drawing.Color.Navy;
            this.TopPanel.Controls.Add(this.bunifuCustomLabel1);
            this.TopPanel.Controls.Add(this.btn_Close);
            this.TopPanel.Controls.Add(this.btn_Minimize);
            this.SalesControlTransition.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.TopPanel, BunifuAnimatorNS.DecorationType.None);
            this.TopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopPanel.Location = new System.Drawing.Point(0, 0);
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.Size = new System.Drawing.Size(1268, 38);
            this.TopPanel.TabIndex = 4;
            this.TopPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TopPanel_MouseDown);
            this.TopPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TopPanel_MouseMove);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.LeftPanelSlide.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 6);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(175, 25);
            this.bunifuCustomLabel1.TabIndex = 6;
            this.bunifuCustomLabel1.Text = "Car Sale Automation";
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Navy;
            this.SalesControlTransition.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.btn_Close, BunifuAnimatorNS.DecorationType.None);
            this.btn_Close.Image = global::CarSaleAutomationV2._0.Properties.Resources.close;
            this.btn_Close.ImageActive = null;
            this.btn_Close.Location = new System.Drawing.Point(1227, 3);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(38, 33);
            this.btn_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_Close.TabIndex = 2;
            this.btn_Close.TabStop = false;
            this.btn_Close.Zoom = 10;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_Minimize
            // 
            this.btn_Minimize.BackColor = System.Drawing.Color.Navy;
            this.SalesControlTransition.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.btn_Minimize, BunifuAnimatorNS.DecorationType.None);
            this.btn_Minimize.Image = global::CarSaleAutomationV2._0.Properties.Resources.minimize;
            this.btn_Minimize.ImageActive = null;
            this.btn_Minimize.Location = new System.Drawing.Point(1183, 3);
            this.btn_Minimize.Name = "btn_Minimize";
            this.btn_Minimize.Size = new System.Drawing.Size(38, 33);
            this.btn_Minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_Minimize.TabIndex = 3;
            this.btn_Minimize.TabStop = false;
            this.btn_Minimize.Zoom = 10;
            this.btn_Minimize.Click += new System.EventHandler(this.btn_Minimize_Click);
            // 
            // LeftPanel
            // 
            this.LeftPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.LeftPanel.Controls.Add(this.btn_Sales);
            this.LeftPanel.Controls.Add(this.btn_ListView);
            this.LeftPanel.Controls.Add(this.btn_Users);
            this.LeftPanel.Controls.Add(this.btn_Dashboard);
            this.LeftPanel.Controls.Add(this.btn_Expenses);
            this.LeftPanel.Controls.Add(this.btn_Customers);
            this.LeftPanel.Controls.Add(this.btn_Purchase);
            this.LeftPanel.Controls.Add(this.btn_Vehicles);
            this.SalesControlTransition.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.LeftPanel, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.LeftPanel.Location = new System.Drawing.Point(0, 38);
            this.LeftPanel.Name = "LeftPanel";
            this.LeftPanel.Size = new System.Drawing.Size(50, 607);
            this.LeftPanel.TabIndex = 5;
            // 
            // btn_Sales
            // 
            this.btn_Sales.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Sales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Sales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Sales.BorderRadius = 0;
            this.btn_Sales.ButtonText = "   SALES";
            this.btn_Sales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardControlTransition.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Sales, BunifuAnimatorNS.DecorationType.None);
            this.btn_Sales.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Sales.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sales.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Sales.Iconimage = global::CarSaleAutomationV2._0.Properties.Resources.Sales;
            this.btn_Sales.Iconimage_right = null;
            this.btn_Sales.Iconimage_right_Selected = null;
            this.btn_Sales.Iconimage_Selected = null;
            this.btn_Sales.IconMarginLeft = 0;
            this.btn_Sales.IconMarginRight = 0;
            this.btn_Sales.IconRightVisible = true;
            this.btn_Sales.IconRightZoom = 0D;
            this.btn_Sales.IconVisible = true;
            this.btn_Sales.IconZoom = 80D;
            this.btn_Sales.IsTab = true;
            this.btn_Sales.Location = new System.Drawing.Point(0, 412);
            this.btn_Sales.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Sales.Name = "btn_Sales";
            this.btn_Sales.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Sales.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Sales.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Sales.selected = false;
            this.btn_Sales.Size = new System.Drawing.Size(220, 44);
            this.btn_Sales.TabIndex = 12;
            this.btn_Sales.Text = "   SALES";
            this.btn_Sales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Sales.Textcolor = System.Drawing.Color.White;
            this.btn_Sales.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sales.Click += new System.EventHandler(this.btn_Sales_Click);
            // 
            // btn_ListView
            // 
            this.btn_ListView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ListView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.SalesControlTransition.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.btn_ListView, BunifuAnimatorNS.DecorationType.None);
            this.btn_ListView.Image = global::CarSaleAutomationV2._0.Properties.Resources.list;
            this.btn_ListView.ImageActive = null;
            this.btn_ListView.Location = new System.Drawing.Point(2, 6);
            this.btn_ListView.Name = "btn_ListView";
            this.btn_ListView.Size = new System.Drawing.Size(45, 44);
            this.btn_ListView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_ListView.TabIndex = 6;
            this.btn_ListView.TabStop = false;
            this.btn_ListView.Zoom = 10;
            this.btn_ListView.Click += new System.EventHandler(this.btn_ListView_Click);
            // 
            // btn_Users
            // 
            this.btn_Users.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Users.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Users.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Users.BorderRadius = 0;
            this.btn_Users.ButtonText = "   USERS";
            this.btn_Users.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardControlTransition.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Users, BunifuAnimatorNS.DecorationType.None);
            this.btn_Users.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Users.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Users.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Users.Iconimage = global::CarSaleAutomationV2._0.Properties.Resources.users;
            this.btn_Users.Iconimage_right = null;
            this.btn_Users.Iconimage_right_Selected = null;
            this.btn_Users.Iconimage_Selected = null;
            this.btn_Users.IconMarginLeft = 0;
            this.btn_Users.IconMarginRight = 0;
            this.btn_Users.IconRightVisible = true;
            this.btn_Users.IconRightZoom = 0D;
            this.btn_Users.IconVisible = true;
            this.btn_Users.IconZoom = 60D;
            this.btn_Users.IsTab = true;
            this.btn_Users.Location = new System.Drawing.Point(0, 356);
            this.btn_Users.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Users.Name = "btn_Users";
            this.btn_Users.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Users.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Users.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Users.selected = false;
            this.btn_Users.Size = new System.Drawing.Size(220, 44);
            this.btn_Users.TabIndex = 11;
            this.btn_Users.Text = "   USERS";
            this.btn_Users.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Users.Textcolor = System.Drawing.Color.White;
            this.btn_Users.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Users.Click += new System.EventHandler(this.btn_Users_Click);
            // 
            // btn_Dashboard
            // 
            this.btn_Dashboard.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Dashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Dashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Dashboard.BorderRadius = 0;
            this.btn_Dashboard.ButtonText = "   DASHBOARD";
            this.btn_Dashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardControlTransition.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Dashboard, BunifuAnimatorNS.DecorationType.None);
            this.btn_Dashboard.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Dashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Dashboard.Iconimage = global::CarSaleAutomationV2._0.Properties.Resources.dashboard__2_;
            this.btn_Dashboard.Iconimage_right = null;
            this.btn_Dashboard.Iconimage_right_Selected = null;
            this.btn_Dashboard.Iconimage_Selected = null;
            this.btn_Dashboard.IconMarginLeft = 0;
            this.btn_Dashboard.IconMarginRight = 0;
            this.btn_Dashboard.IconRightVisible = true;
            this.btn_Dashboard.IconRightZoom = 0D;
            this.btn_Dashboard.IconVisible = true;
            this.btn_Dashboard.IconZoom = 60D;
            this.btn_Dashboard.IsTab = true;
            this.btn_Dashboard.Location = new System.Drawing.Point(0, 76);
            this.btn_Dashboard.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Dashboard.Name = "btn_Dashboard";
            this.btn_Dashboard.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Dashboard.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Dashboard.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Dashboard.selected = false;
            this.btn_Dashboard.Size = new System.Drawing.Size(220, 44);
            this.btn_Dashboard.TabIndex = 7;
            this.btn_Dashboard.Text = "   DASHBOARD";
            this.btn_Dashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Dashboard.Textcolor = System.Drawing.Color.White;
            this.btn_Dashboard.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dashboard.Click += new System.EventHandler(this.btn_Dashboard_Click);
            // 
            // btn_Expenses
            // 
            this.btn_Expenses.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Expenses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Expenses.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Expenses.BorderRadius = 0;
            this.btn_Expenses.ButtonText = "   EXPENSES";
            this.btn_Expenses.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardControlTransition.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Expenses, BunifuAnimatorNS.DecorationType.None);
            this.btn_Expenses.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Expenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Expenses.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Expenses.Iconimage = global::CarSaleAutomationV2._0.Properties.Resources.expenses;
            this.btn_Expenses.Iconimage_right = null;
            this.btn_Expenses.Iconimage_right_Selected = null;
            this.btn_Expenses.Iconimage_Selected = null;
            this.btn_Expenses.IconMarginLeft = 0;
            this.btn_Expenses.IconMarginRight = 0;
            this.btn_Expenses.IconRightVisible = true;
            this.btn_Expenses.IconRightZoom = 0D;
            this.btn_Expenses.IconVisible = true;
            this.btn_Expenses.IconZoom = 60D;
            this.btn_Expenses.IsTab = true;
            this.btn_Expenses.Location = new System.Drawing.Point(0, 300);
            this.btn_Expenses.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Expenses.Name = "btn_Expenses";
            this.btn_Expenses.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Expenses.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Expenses.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Expenses.selected = false;
            this.btn_Expenses.Size = new System.Drawing.Size(220, 44);
            this.btn_Expenses.TabIndex = 10;
            this.btn_Expenses.Text = "   EXPENSES";
            this.btn_Expenses.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Expenses.Textcolor = System.Drawing.Color.White;
            this.btn_Expenses.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Expenses.Click += new System.EventHandler(this.btn_Expenses_Click);
            // 
            // btn_Customers
            // 
            this.btn_Customers.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Customers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Customers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Customers.BorderRadius = 0;
            this.btn_Customers.ButtonText = "   CUSTOMERS";
            this.btn_Customers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardControlTransition.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Customers, BunifuAnimatorNS.DecorationType.None);
            this.btn_Customers.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Customers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Customers.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Customers.Iconimage = global::CarSaleAutomationV2._0.Properties.Resources.customers;
            this.btn_Customers.Iconimage_right = null;
            this.btn_Customers.Iconimage_right_Selected = null;
            this.btn_Customers.Iconimage_Selected = null;
            this.btn_Customers.IconMarginLeft = 0;
            this.btn_Customers.IconMarginRight = 0;
            this.btn_Customers.IconRightVisible = true;
            this.btn_Customers.IconRightZoom = 0D;
            this.btn_Customers.IconVisible = true;
            this.btn_Customers.IconZoom = 60D;
            this.btn_Customers.IsTab = true;
            this.btn_Customers.Location = new System.Drawing.Point(0, 132);
            this.btn_Customers.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Customers.Name = "btn_Customers";
            this.btn_Customers.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Customers.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Customers.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Customers.selected = false;
            this.btn_Customers.Size = new System.Drawing.Size(220, 44);
            this.btn_Customers.TabIndex = 6;
            this.btn_Customers.Text = "   CUSTOMERS";
            this.btn_Customers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Customers.Textcolor = System.Drawing.Color.White;
            this.btn_Customers.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Customers.Click += new System.EventHandler(this.btn_Customers_Click);
            // 
            // btn_Purchase
            // 
            this.btn_Purchase.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Purchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Purchase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Purchase.BorderRadius = 0;
            this.btn_Purchase.ButtonText = "   PURCHASE";
            this.btn_Purchase.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardControlTransition.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Purchase, BunifuAnimatorNS.DecorationType.None);
            this.btn_Purchase.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Purchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Purchase.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Purchase.Iconimage = global::CarSaleAutomationV2._0.Properties.Resources.cart;
            this.btn_Purchase.Iconimage_right = null;
            this.btn_Purchase.Iconimage_right_Selected = null;
            this.btn_Purchase.Iconimage_Selected = null;
            this.btn_Purchase.IconMarginLeft = 0;
            this.btn_Purchase.IconMarginRight = 0;
            this.btn_Purchase.IconRightVisible = true;
            this.btn_Purchase.IconRightZoom = 0D;
            this.btn_Purchase.IconVisible = true;
            this.btn_Purchase.IconZoom = 60D;
            this.btn_Purchase.IsTab = true;
            this.btn_Purchase.Location = new System.Drawing.Point(0, 244);
            this.btn_Purchase.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Purchase.Name = "btn_Purchase";
            this.btn_Purchase.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Purchase.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Purchase.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Purchase.selected = false;
            this.btn_Purchase.Size = new System.Drawing.Size(220, 44);
            this.btn_Purchase.TabIndex = 9;
            this.btn_Purchase.Text = "   PURCHASE";
            this.btn_Purchase.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Purchase.Textcolor = System.Drawing.Color.White;
            this.btn_Purchase.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Purchase.Click += new System.EventHandler(this.btn_Purchase_Click);
            // 
            // btn_Vehicles
            // 
            this.btn_Vehicles.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Vehicles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Vehicles.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Vehicles.BorderRadius = 0;
            this.btn_Vehicles.ButtonText = "   Vehicles";
            this.btn_Vehicles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardControlTransition.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.btn_Vehicles, BunifuAnimatorNS.DecorationType.None);
            this.btn_Vehicles.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Vehicles.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Vehicles.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Vehicles.Iconimage = global::CarSaleAutomationV2._0.Properties.Resources.vehicles;
            this.btn_Vehicles.Iconimage_right = null;
            this.btn_Vehicles.Iconimage_right_Selected = null;
            this.btn_Vehicles.Iconimage_Selected = null;
            this.btn_Vehicles.IconMarginLeft = 0;
            this.btn_Vehicles.IconMarginRight = 0;
            this.btn_Vehicles.IconRightVisible = true;
            this.btn_Vehicles.IconRightZoom = 0D;
            this.btn_Vehicles.IconVisible = true;
            this.btn_Vehicles.IconZoom = 60D;
            this.btn_Vehicles.IsTab = true;
            this.btn_Vehicles.Location = new System.Drawing.Point(0, 188);
            this.btn_Vehicles.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Vehicles.Name = "btn_Vehicles";
            this.btn_Vehicles.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(52)))));
            this.btn_Vehicles.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.btn_Vehicles.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Vehicles.selected = false;
            this.btn_Vehicles.Size = new System.Drawing.Size(220, 44);
            this.btn_Vehicles.TabIndex = 8;
            this.btn_Vehicles.Text = "   Vehicles";
            this.btn_Vehicles.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Vehicles.Textcolor = System.Drawing.Color.White;
            this.btn_Vehicles.TextFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Vehicles.Click += new System.EventHandler(this.btn_Vehicles_Click);
            // 
            // LeftPanelSlide
            // 
            this.LeftPanelSlide.AnimationType = BunifuAnimatorNS.AnimationType.HorizSlide;
            this.LeftPanelSlide.Cursor = null;
            animation19.AnimateOnlyDifferences = true;
            animation19.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation19.BlindCoeff")));
            animation19.LeafCoeff = 0F;
            animation19.MaxTime = 1F;
            animation19.MinTime = 0F;
            animation19.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation19.MosaicCoeff")));
            animation19.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation19.MosaicShift")));
            animation19.MosaicSize = 0;
            animation19.Padding = new System.Windows.Forms.Padding(0);
            animation19.RotateCoeff = 0F;
            animation19.RotateLimit = 0F;
            animation19.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation19.ScaleCoeff")));
            animation19.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation19.SlideCoeff")));
            animation19.TimeCoeff = 0F;
            animation19.TransparencyCoeff = 0F;
            this.LeftPanelSlide.DefaultAnimation = animation19;
            // 
            // RIghtPanel
            // 
            this.RIghtPanel.Controls.Add(this.SalesControl);
            this.RIghtPanel.Controls.Add(this.DashboardControl);
            this.RIghtPanel.Controls.Add(this.ExpensesControl);
            this.RIghtPanel.Controls.Add(this.PurchaseControl);
            this.RIghtPanel.Controls.Add(this.UsersControl);
            this.RIghtPanel.Controls.Add(this.VehicleControl);
            this.RIghtPanel.Controls.Add(this.CustomerControl);
            this.SalesControlTransition.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.RIghtPanel, BunifuAnimatorNS.DecorationType.None);
            this.RIghtPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RIghtPanel.Location = new System.Drawing.Point(50, 38);
            this.RIghtPanel.Name = "RIghtPanel";
            this.RIghtPanel.Size = new System.Drawing.Size(1218, 607);
            this.RIghtPanel.TabIndex = 7;
            // 
            // SalesControl
            // 
            this.SalesControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.UsersControlTransition.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.SalesControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControl.Location = new System.Drawing.Point(84, 0);
            this.SalesControl.Name = "SalesControl";
            this.SalesControl.Size = new System.Drawing.Size(1027, 589);
            this.SalesControl.TabIndex = 6;
            // 
            // DashboardControl
            // 
            this.DashboardControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.UsersControlTransition.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.DashboardControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControl.Location = new System.Drawing.Point(84, 3);
            this.DashboardControl.Name = "DashboardControl";
            this.DashboardControl.Size = new System.Drawing.Size(1027, 589);
            this.DashboardControl.TabIndex = 5;
            // 
            // ExpensesControl
            // 
            this.ExpensesControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.UsersControlTransition.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.ExpensesControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControl.Location = new System.Drawing.Point(84, 3);
            this.ExpensesControl.Name = "ExpensesControl";
            this.ExpensesControl.Size = new System.Drawing.Size(1027, 589);
            this.ExpensesControl.TabIndex = 4;
            // 
            // PurchaseControl
            // 
            this.PurchaseControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.UsersControlTransition.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.PurchaseControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControl.Location = new System.Drawing.Point(84, 3);
            this.PurchaseControl.Name = "PurchaseControl";
            this.PurchaseControl.Size = new System.Drawing.Size(1027, 589);
            this.PurchaseControl.TabIndex = 3;
            // 
            // UsersControl
            // 
            this.UsersControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.UsersControlTransition.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.UsersControl, BunifuAnimatorNS.DecorationType.None);
            this.UsersControl.Location = new System.Drawing.Point(84, 3);
            this.UsersControl.Name = "UsersControl";
            this.UsersControl.Size = new System.Drawing.Size(1027, 589);
            this.UsersControl.TabIndex = 2;
            // 
            // VehicleControl
            // 
            this.VehicleControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.UsersControlTransition.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.VehicleControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControl.Location = new System.Drawing.Point(84, 0);
            this.VehicleControl.Name = "VehicleControl";
            this.VehicleControl.Size = new System.Drawing.Size(1027, 589);
            this.VehicleControl.TabIndex = 1;
            // 
            // CustomerControl
            // 
            this.CustomerControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.UsersControlTransition.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.ExpensesControlTransition.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this.CustomerControl, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControl.Location = new System.Drawing.Point(84, 3);
            this.CustomerControl.Name = "CustomerControl";
            this.CustomerControl.Size = new System.Drawing.Size(1027, 589);
            this.CustomerControl.TabIndex = 0;
            // 
            // CustomerControlTransition
            // 
            this.CustomerControlTransition.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.CustomerControlTransition.Cursor = null;
            animation18.AnimateOnlyDifferences = true;
            animation18.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation18.BlindCoeff")));
            animation18.LeafCoeff = 0F;
            animation18.MaxTime = 1F;
            animation18.MinTime = 0F;
            animation18.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation18.MosaicCoeff")));
            animation18.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation18.MosaicShift")));
            animation18.MosaicSize = 0;
            animation18.Padding = new System.Windows.Forms.Padding(0);
            animation18.RotateCoeff = 0F;
            animation18.RotateLimit = 0F;
            animation18.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation18.ScaleCoeff")));
            animation18.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation18.SlideCoeff")));
            animation18.TimeCoeff = 0F;
            animation18.TransparencyCoeff = 1F;
            this.CustomerControlTransition.DefaultAnimation = animation18;
            // 
            // VehicleControlTransition
            // 
            this.VehicleControlTransition.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.VehicleControlTransition.Cursor = null;
            animation21.AnimateOnlyDifferences = true;
            animation21.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation21.BlindCoeff")));
            animation21.LeafCoeff = 0F;
            animation21.MaxTime = 1F;
            animation21.MinTime = 0F;
            animation21.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation21.MosaicCoeff")));
            animation21.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation21.MosaicShift")));
            animation21.MosaicSize = 0;
            animation21.Padding = new System.Windows.Forms.Padding(0);
            animation21.RotateCoeff = 0F;
            animation21.RotateLimit = 0F;
            animation21.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation21.ScaleCoeff")));
            animation21.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation21.SlideCoeff")));
            animation21.TimeCoeff = 0F;
            animation21.TransparencyCoeff = 1F;
            this.VehicleControlTransition.DefaultAnimation = animation21;
            // 
            // UsersControlTransition
            // 
            this.UsersControlTransition.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.UsersControlTransition.Cursor = null;
            animation20.AnimateOnlyDifferences = true;
            animation20.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation20.BlindCoeff")));
            animation20.LeafCoeff = 0F;
            animation20.MaxTime = 1F;
            animation20.MinTime = 0F;
            animation20.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation20.MosaicCoeff")));
            animation20.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation20.MosaicShift")));
            animation20.MosaicSize = 0;
            animation20.Padding = new System.Windows.Forms.Padding(0);
            animation20.RotateCoeff = 0F;
            animation20.RotateLimit = 0F;
            animation20.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation20.ScaleCoeff")));
            animation20.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation20.SlideCoeff")));
            animation20.TimeCoeff = 0F;
            animation20.TransparencyCoeff = 1F;
            this.UsersControlTransition.DefaultAnimation = animation20;
            // 
            // PurchaseControlTransition
            // 
            this.PurchaseControlTransition.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.PurchaseControlTransition.Cursor = null;
            animation23.AnimateOnlyDifferences = true;
            animation23.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation23.BlindCoeff")));
            animation23.LeafCoeff = 0F;
            animation23.MaxTime = 1F;
            animation23.MinTime = 0F;
            animation23.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation23.MosaicCoeff")));
            animation23.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation23.MosaicShift")));
            animation23.MosaicSize = 0;
            animation23.Padding = new System.Windows.Forms.Padding(0);
            animation23.RotateCoeff = 0F;
            animation23.RotateLimit = 0F;
            animation23.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation23.ScaleCoeff")));
            animation23.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation23.SlideCoeff")));
            animation23.TimeCoeff = 0F;
            animation23.TransparencyCoeff = 1F;
            this.PurchaseControlTransition.DefaultAnimation = animation23;
            // 
            // ExpensesControlTransition
            // 
            this.ExpensesControlTransition.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.ExpensesControlTransition.Cursor = null;
            animation22.AnimateOnlyDifferences = true;
            animation22.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation22.BlindCoeff")));
            animation22.LeafCoeff = 0F;
            animation22.MaxTime = 1F;
            animation22.MinTime = 0F;
            animation22.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation22.MosaicCoeff")));
            animation22.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation22.MosaicShift")));
            animation22.MosaicSize = 0;
            animation22.Padding = new System.Windows.Forms.Padding(0);
            animation22.RotateCoeff = 0F;
            animation22.RotateLimit = 0F;
            animation22.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation22.ScaleCoeff")));
            animation22.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation22.SlideCoeff")));
            animation22.TimeCoeff = 0F;
            animation22.TransparencyCoeff = 1F;
            this.ExpensesControlTransition.DefaultAnimation = animation22;
            // 
            // DashboardControlTransition
            // 
            this.DashboardControlTransition.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.DashboardControlTransition.Cursor = null;
            animation24.AnimateOnlyDifferences = true;
            animation24.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation24.BlindCoeff")));
            animation24.LeafCoeff = 0F;
            animation24.MaxTime = 1F;
            animation24.MinTime = 0F;
            animation24.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation24.MosaicCoeff")));
            animation24.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation24.MosaicShift")));
            animation24.MosaicSize = 0;
            animation24.Padding = new System.Windows.Forms.Padding(0);
            animation24.RotateCoeff = 0F;
            animation24.RotateLimit = 0F;
            animation24.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation24.ScaleCoeff")));
            animation24.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation24.SlideCoeff")));
            animation24.TimeCoeff = 0F;
            animation24.TransparencyCoeff = 1F;
            this.DashboardControlTransition.DefaultAnimation = animation24;
            // 
            // SalesControlTransition
            // 
            this.SalesControlTransition.AnimationType = BunifuAnimatorNS.AnimationType.Transparent;
            this.SalesControlTransition.Cursor = null;
            animation17.AnimateOnlyDifferences = true;
            animation17.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation17.BlindCoeff")));
            animation17.LeafCoeff = 0F;
            animation17.MaxTime = 1F;
            animation17.MinTime = 0F;
            animation17.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation17.MosaicCoeff")));
            animation17.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation17.MosaicShift")));
            animation17.MosaicSize = 0;
            animation17.Padding = new System.Windows.Forms.Padding(0);
            animation17.RotateCoeff = 0F;
            animation17.RotateLimit = 0F;
            animation17.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation17.ScaleCoeff")));
            animation17.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation17.SlideCoeff")));
            animation17.TimeCoeff = 0F;
            animation17.TransparencyCoeff = 1F;
            this.SalesControlTransition.DefaultAnimation = animation17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(1268, 645);
            this.Controls.Add(this.RIghtPanel);
            this.Controls.Add(this.LeftPanel);
            this.Controls.Add(this.TopPanel);
            this.ExpensesControlTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.UsersControlTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.PurchaseControlTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.LeftPanelSlide.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.SalesControlTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.DashboardControlTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.VehicleControlTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.CustomerControlTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TopPanel.ResumeLayout(false);
            this.TopPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Minimize)).EndInit();
            this.LeftPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_ListView)).EndInit();
            this.RIghtPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Bunifu.Framework.UI.BunifuImageButton btn_Close;
        private Bunifu.Framework.UI.BunifuImageButton btn_Minimize;
        private System.Windows.Forms.Panel TopPanel;
        private System.Windows.Forms.Panel LeftPanel;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Customers;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Dashboard;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Vehicles;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Purchase;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Expenses;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Users;
        private Bunifu.Framework.UI.BunifuImageButton btn_ListView;
        private BunifuAnimatorNS.BunifuTransition LeftPanelSlide;
        private BunifuAnimatorNS.BunifuTransition CustomerControlTransition;
        private System.Windows.Forms.Panel RIghtPanel;
        private CustomerControl CustomerControl;
        private BunifuAnimatorNS.BunifuTransition VehicleControlTransition;
        private VehicleControl VehicleControl;
        private BunifuAnimatorNS.BunifuTransition UsersControlTransition;
        private UsersControl UsersControl;
        private BunifuAnimatorNS.BunifuTransition PurchaseControlTransition;
        private PurchaseControl PurchaseControl;
        private BunifuAnimatorNS.BunifuTransition ExpensesControlTransition;
        private ExpensesControl ExpensesControl;
        private BunifuAnimatorNS.BunifuTransition DashboardControlTransition;
        private DashboardControl DashboardControl;
        private BunifuAnimatorNS.BunifuTransition SalesControlTransition;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Sales;
        private SalesControl SalesControl;
    }
}

