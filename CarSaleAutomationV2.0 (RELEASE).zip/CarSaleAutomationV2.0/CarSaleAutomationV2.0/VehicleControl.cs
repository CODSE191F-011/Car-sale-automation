﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CarSaleAutomationV2._0
{
    public partial class VehicleControl : UserControl
    {
        Database db = new Database();
        Imaging imaging = new Imaging();
        public VehicleControl()
        {
            InitializeComponent();
        }

        private void btn_Browse_Click(object sender, EventArgs e)
        {
            try
            {
                DefaultImage.Visible = false;
                VehicleImage.Visible = true;
                openFileDialog.ShowDialog();
                VehicleImage.Image = Image.FromFile(openFileDialog.FileName);
            }
            catch (OutOfMemoryException)
            {
                MessageBox.Show("Please select images only", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Please select an image", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void VehicleControl_Load(object sender, EventArgs e)
        {
            string query = $"SELECT VehicleId FROM Vehicles WHERE VehicleNo = (SELECT TOP 1 VehicleNo FROM Vehicles ORDER BY VehicleNo DESC);";
            try
            {
                if (db.NextId(query) == "empty")
                {
                    txtbx_Index.Text = "V1";
                }
                else
                {
                    txtbx_Index.Text = db.NextId(query);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("No Data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            DefaultImage.Visible = true;
            VehicleImage.Visible = false;
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtbx_Index.Text))
            {
                MessageBox.Show("Index cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Company.Text))
            {
                MessageBox.Show("Company name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Company.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Company name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Model.Text))
            {
                MessageBox.Show("Model name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Color.Text))
            {
                MessageBox.Show("Color cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_ChassisNo.Text))
            {
                MessageBox.Show("Chassis No cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Meter.Text))
            {
                MessageBox.Show("Meter cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Meter.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Meter cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Price.Text))
            {
                MessageBox.Show("Price cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Price.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Price cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    string currentUser = db.GetLoggedInUser();
                    string arr = imaging.ImageToBase64(VehicleImage.Image, System.Drawing.Imaging.ImageFormat.Jpeg);
                    string query = $"INSERT INTO Vehicles VALUES ('{txtbx_Index.Text}','{txtbx_Company.Text}','{txtbx_Model.Text}','{txtbx_Color.Text}','{txtbx_ChassisNo.Text}','{txtbx_Meter.Text}','{txtbx_Price.Text}','{arr}','{currentUser}')";
                    int i = db.Save_Update_Delete(query);
                    if (i == 1)
                    {
                        MessageBox.Show("Data saved successfully", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtbx_Index.Text = "";
                        txtbx_Company.Text = "";
                        txtbx_Model.Text = "";
                        txtbx_Color.Text = "";
                        txtbx_ChassisNo.Text = "";
                        txtbx_Meter.Text = "";
                        txtbx_Price.Text = "";
                        DefaultImage.Visible = true;
                        VehicleImage.Visible = false;
                        string query2 = $"SELECT VehicleId FROM Vehicles WHERE VehicleNo = (SELECT TOP 1 VehicleNo FROM Vehicles ORDER BY VehicleNo DESC);";
                        try
                        {
                            if (db.NextId(query2) == "empty")
                            {
                                txtbx_Index.Text = "V1";
                            }
                            else
                            {
                                txtbx_Index.Text = db.NextId(query2);
                            }
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("No Data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot save", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException)
                {
                    MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtbx_Index.Text))
            {
                MessageBox.Show("Index cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Company.Text))
            {
                MessageBox.Show("Company name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Company.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Company name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Model.Text))
            {
                MessageBox.Show("Model name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Color.Text))
            {
                MessageBox.Show("Color cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_ChassisNo.Text))
            {
                MessageBox.Show("Chassis No cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Meter.Text))
            {
                MessageBox.Show("Meter cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Meter.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Meter cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Price.Text))
            {
                MessageBox.Show("Price cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Price.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Price cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    string arr = imaging.ImageToBase64(VehicleImage.Image, System.Drawing.Imaging.ImageFormat.Jpeg);
                    string query = $"UPDATE Vehicles SET Company = '{txtbx_Company.Text}',Model = '{txtbx_Model.Text}',Color = '{txtbx_Color.Text}',ChassisNo = '{txtbx_ChassisNo.Text}',Meter = '{txtbx_Meter.Text}',Price = '{txtbx_Price.Text}',Photo = '{arr}' WHERE VehicleId = '{txtbx_Index.Text}'";
                    int i = db.Save_Update_Delete(query);
                    if (i == 1)
                    {
                        MessageBox.Show("Data updated successfully", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtbx_Index.Text = "";
                        txtbx_Company.Text = "";
                        txtbx_Model.Text = "";
                        txtbx_Color.Text = "";
                        txtbx_ChassisNo.Text = "";
                        txtbx_Meter.Text = "";
                        txtbx_Price.Text = "";
                        txtbx_SearchModel.Text = "";
                        txtbx_SearchColor.Text = "";
                        DefaultImage.Visible = true;
                        VehicleImage.Visible = false;
                        string query2 = $"SELECT VehicleId FROM Vehicles WHERE VehicleNo = (SELECT TOP 1 VehicleNo FROM Vehicles ORDER BY VehicleNo DESC);";
                        try
                        {
                            if (db.NextId(query2) == "empty")
                            {
                                txtbx_Index.Text = "V1";
                            }
                            else
                            {
                                txtbx_Index.Text = db.NextId(query2);
                            }
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("No records", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot update data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException)
                {
                    MessageBox.Show("Cannot update data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            try
            {
                //string arr = imaging.ImageToBase64(CapturedImage.Image, System.Drawing.Imaging.ImageFormat.Jpeg);
                string query = $"DELETE FROM Vehicles WHERE VehicleId = '{txtbx_Index.Text}'";
                int i = db.Save_Update_Delete(query);
                if (i == 1)
                {
                    MessageBox.Show("Data removed", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtbx_Company.Text = "";
                    txtbx_Model.Text = "";
                    txtbx_Color.Text = "";
                    txtbx_Meter.Text = "";
                    txtbx_Price.Text = "";
                    txtbx_ChassisNo.Text = "";
                    txtbx_Index.Text = "";
                    txtbx_SearchModel.Text = "";
                    txtbx_SearchColor.Text = "";
                    DefaultImage.Visible = true;
                    VehicleImage.Visible = false;
                    string query2 = $"SELECT VehicleId FROM Vehicles WHERE VehicleNo = (SELECT TOP 1 VehicleNo FROM Vehicles ORDER BY VehicleNo DESC);";
                    try
                    {
                        if (db.NextId(query2) == "empty")
                        {
                            txtbx_Index.Text = "V1";
                        }
                        else
                        {
                            txtbx_Index.Text = db.NextId(query2);
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("No records", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Cannot remove data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Cannot remove data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txtbx_Company.Text = "";
            txtbx_Model.Text = "";
            txtbx_Color.Text = "";
            txtbx_Meter.Text = "";
            txtbx_Price.Text = "";
            txtbx_ChassisNo.Text = "";
            txtbx_Index.Text = "";
            txtbx_SearchModel.Text = "";
            txtbx_SearchColor.Text = "";
            DefaultImage.Visible = true;
            VehicleImage.Visible = false;
            string query2 = $"SELECT VehicleId FROM Vehicles WHERE VehicleNo = (SELECT TOP 1 VehicleNo FROM Vehicles ORDER BY VehicleNo DESC);";
            try
            {
                if (db.NextId(query2) == "empty")
                {
                    txtbx_Index.Text = "V1";
                }
                else
                {
                    txtbx_Index.Text = db.NextId(query2);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("No records", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT * FROM Vehicles WHERE Model = '{txtbx_SearchModel.Text}' AND Color = '{txtbx_SearchColor.Text}'";
                SqlDataReader reader = db.ReadData(query);
                if (reader.HasRows)
                {
                    txtbx_Index.Text = reader[1].ToString();
                    txtbx_Company.Text = reader[2].ToString();
                    txtbx_Model.Text = reader[3].ToString();
                    txtbx_Color.Text = reader[4].ToString();
                    txtbx_ChassisNo.Text = reader[5].ToString();
                    txtbx_Meter.Text = reader[6].ToString();
                    txtbx_Price.Text = reader[7].ToString();
                    DefaultImage.Visible = false;
                    VehicleImage.Visible = true;
                    VehicleImage.Image = imaging.Base64ToImage(reader[8].ToString());
                    db.CloseConnection();
                }
                else
                {
                    MessageBox.Show("No data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    db.CloseConnection();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                db.CloseConnection();
            }
        }
    }
}
