﻿namespace CarSaleAutomationV2._0
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.MainPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_Close = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_UserName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Password = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_LogIn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Close)).BeginInit();
            this.SuspendLayout();
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this.btn_LogIn);
            this.MainPanel.Controls.Add(this.txtbx_Password);
            this.MainPanel.Controls.Add(this.bunifuCustomLabel3);
            this.MainPanel.Controls.Add(this.bunifuCustomLabel2);
            this.MainPanel.Controls.Add(this.txtbx_UserName);
            this.MainPanel.Controls.Add(this.bunifuCustomLabel1);
            this.MainPanel.Controls.Add(this.bunifuSeparator2);
            this.MainPanel.Controls.Add(this.bunifuSeparator1);
            this.MainPanel.Controls.Add(this.pictureBox1);
            this.MainPanel.Controls.Add(this.btn_Close);
            this.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainPanel.Location = new System.Drawing.Point(0, 0);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(409, 581);
            this.MainPanel.TabIndex = 0;
            this.MainPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainPanel_MouseDown);
            this.MainPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainPanel_MouseMove);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CarSaleAutomationV2._0.Properties.Resources.homes4;
            this.pictureBox1.Location = new System.Drawing.Point(179, 86);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(51, 58);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Close.Image = global::CarSaleAutomationV2._0.Properties.Resources.close3;
            this.btn_Close.ImageActive = null;
            this.btn_Close.Location = new System.Drawing.Point(362, 3);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(44, 42);
            this.btn_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_Close.TabIndex = 0;
            this.btn_Close.TabStop = false;
            this.btn_Close.Zoom = 10;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.White;
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(34, 86);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(138, 58);
            this.bunifuSeparator1.TabIndex = 2;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(237, 86);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(138, 58);
            this.bunifuSeparator2.TabIndex = 3;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Dense", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(110, 178);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(192, 40);
            this.bunifuCustomLabel1.TabIndex = 4;
            this.bunifuCustomLabel1.Text = "Log in to see more";
            // 
            // txtbx_UserName
            // 
            this.txtbx_UserName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_UserName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_UserName.ForeColor = System.Drawing.Color.White;
            this.txtbx_UserName.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_UserName.HintText = "username";
            this.txtbx_UserName.isPassword = false;
            this.txtbx_UserName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_UserName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_UserName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_UserName.LineThickness = 3;
            this.txtbx_UserName.Location = new System.Drawing.Point(58, 284);
            this.txtbx_UserName.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_UserName.Name = "txtbx_UserName";
            this.txtbx_UserName.Size = new System.Drawing.Size(295, 44);
            this.txtbx_UserName.TabIndex = 5;
            this.txtbx_UserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(53, 253);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(104, 27);
            this.bunifuCustomLabel2.TabIndex = 6;
            this.bunifuCustomLabel2.Text = "Username";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(53, 352);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(97, 27);
            this.bunifuCustomLabel3.TabIndex = 7;
            this.bunifuCustomLabel3.Text = "Password";
            // 
            // txtbx_Password
            // 
            this.txtbx_Password.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Password.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_Password.ForeColor = System.Drawing.Color.White;
            this.txtbx_Password.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Password.HintText = "";
            this.txtbx_Password.isPassword = true;
            this.txtbx_Password.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Password.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Password.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Password.LineThickness = 3;
            this.txtbx_Password.Location = new System.Drawing.Point(58, 383);
            this.txtbx_Password.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Password.Name = "txtbx_Password";
            this.txtbx_Password.Size = new System.Drawing.Size(295, 44);
            this.txtbx_Password.TabIndex = 8;
            this.txtbx_Password.Text = "1";
            this.txtbx_Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_LogIn
            // 
            this.btn_LogIn.ActiveBorderThickness = 1;
            this.btn_LogIn.ActiveCornerRadius = 20;
            this.btn_LogIn.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_LogIn.ActiveForecolor = System.Drawing.Color.White;
            this.btn_LogIn.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_LogIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_LogIn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_LogIn.BackgroundImage")));
            this.btn_LogIn.ButtonText = "Log In";
            this.btn_LogIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_LogIn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LogIn.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn_LogIn.IdleBorderThickness = 1;
            this.btn_LogIn.IdleCornerRadius = 20;
            this.btn_LogIn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_LogIn.IdleForecolor = System.Drawing.Color.White;
            this.btn_LogIn.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_LogIn.Location = new System.Drawing.Point(58, 456);
            this.btn_LogIn.Margin = new System.Windows.Forms.Padding(5);
            this.btn_LogIn.Name = "btn_LogIn";
            this.btn_LogIn.Size = new System.Drawing.Size(295, 41);
            this.btn_LogIn.TabIndex = 9;
            this.btn_LogIn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_LogIn.Click += new System.EventHandler(this.btn_LogIn_Click);
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(409, 581);
            this.Controls.Add(this.MainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoginForm";
            this.Text = "LoginForm";
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Close)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MainPanel;
        private Bunifu.Framework.UI.BunifuImageButton btn_Close;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_LogIn;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Password;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_UserName;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
    }
}