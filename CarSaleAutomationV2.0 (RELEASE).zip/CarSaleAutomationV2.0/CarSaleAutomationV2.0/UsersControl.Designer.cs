﻿namespace CarSaleAutomationV2._0
{
    partial class UsersControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UsersControl));
            this.txtbx_LastName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_UserName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Confirm = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_Password = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_FirstName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_SignUp = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_UserId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtbx_LastName
            // 
            this.txtbx_LastName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_LastName.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_LastName.ForeColor = System.Drawing.Color.White;
            this.txtbx_LastName.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_LastName.HintText = "";
            this.txtbx_LastName.isPassword = false;
            this.txtbx_LastName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_LastName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_LastName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_LastName.LineThickness = 3;
            this.txtbx_LastName.Location = new System.Drawing.Point(443, 285);
            this.txtbx_LastName.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_LastName.Name = "txtbx_LastName";
            this.txtbx_LastName.Size = new System.Drawing.Size(289, 44);
            this.txtbx_LastName.TabIndex = 12;
            this.txtbx_LastName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(305, 302);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(112, 27);
            this.bunifuCustomLabel3.TabIndex = 10;
            this.bunifuCustomLabel3.Text = "Last Name";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(304, 250);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(115, 27);
            this.bunifuCustomLabel2.TabIndex = 9;
            this.bunifuCustomLabel2.Text = "First Name";
            // 
            // txtbx_UserName
            // 
            this.txtbx_UserName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_UserName.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_UserName.ForeColor = System.Drawing.Color.White;
            this.txtbx_UserName.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_UserName.HintText = "";
            this.txtbx_UserName.isPassword = false;
            this.txtbx_UserName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_UserName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_UserName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_UserName.LineThickness = 3;
            this.txtbx_UserName.Location = new System.Drawing.Point(443, 337);
            this.txtbx_UserName.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_UserName.Name = "txtbx_UserName";
            this.txtbx_UserName.Size = new System.Drawing.Size(289, 44);
            this.txtbx_UserName.TabIndex = 14;
            this.txtbx_UserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(305, 354);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(118, 27);
            this.bunifuCustomLabel1.TabIndex = 13;
            this.bunifuCustomLabel1.Text = "User Name";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(305, 458);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(89, 27);
            this.bunifuCustomLabel4.TabIndex = 16;
            this.bunifuCustomLabel4.Text = "Confirm";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(304, 406);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(103, 27);
            this.bunifuCustomLabel5.TabIndex = 15;
            this.bunifuCustomLabel5.Text = "Password";
            // 
            // txtbx_Confirm
            // 
            this.txtbx_Confirm.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Confirm.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_Confirm.ForeColor = System.Drawing.Color.White;
            this.txtbx_Confirm.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Confirm.HintText = "";
            this.txtbx_Confirm.isPassword = true;
            this.txtbx_Confirm.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Confirm.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Confirm.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Confirm.LineThickness = 3;
            this.txtbx_Confirm.Location = new System.Drawing.Point(443, 441);
            this.txtbx_Confirm.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Confirm.Name = "txtbx_Confirm";
            this.txtbx_Confirm.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Confirm.TabIndex = 17;
            this.txtbx_Confirm.Text = "1";
            this.txtbx_Confirm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_Password
            // 
            this.txtbx_Password.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Password.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_Password.ForeColor = System.Drawing.Color.White;
            this.txtbx_Password.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Password.HintText = "";
            this.txtbx_Password.isPassword = true;
            this.txtbx_Password.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Password.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Password.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Password.LineThickness = 3;
            this.txtbx_Password.Location = new System.Drawing.Point(443, 389);
            this.txtbx_Password.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Password.Name = "txtbx_Password";
            this.txtbx_Password.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Password.TabIndex = 18;
            this.txtbx_Password.Text = "1";
            this.txtbx_Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CarSaleAutomationV2._0.Properties.Resources.icons8_change_user_100_1_;
            this.pictureBox1.Location = new System.Drawing.Point(443, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 106);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(3, 0);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(80, 34);
            this.bunifuCustomLabel6.TabIndex = 20;
            this.bunifuCustomLabel6.Text = "Users";
            // 
            // txtbx_FirstName
            // 
            this.txtbx_FirstName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_FirstName.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_FirstName.ForeColor = System.Drawing.Color.White;
            this.txtbx_FirstName.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_FirstName.HintText = "";
            this.txtbx_FirstName.isPassword = false;
            this.txtbx_FirstName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_FirstName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_FirstName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_FirstName.LineThickness = 3;
            this.txtbx_FirstName.Location = new System.Drawing.Point(443, 233);
            this.txtbx_FirstName.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_FirstName.Name = "txtbx_FirstName";
            this.txtbx_FirstName.Size = new System.Drawing.Size(289, 44);
            this.txtbx_FirstName.TabIndex = 21;
            this.txtbx_FirstName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_SignUp
            // 
            this.btn_SignUp.ActiveBorderThickness = 1;
            this.btn_SignUp.ActiveCornerRadius = 20;
            this.btn_SignUp.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_SignUp.ActiveForecolor = System.Drawing.Color.White;
            this.btn_SignUp.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_SignUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_SignUp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_SignUp.BackgroundImage")));
            this.btn_SignUp.ButtonText = "Sign Up";
            this.btn_SignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_SignUp.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SignUp.ForeColor = System.Drawing.Color.White;
            this.btn_SignUp.IdleBorderThickness = 1;
            this.btn_SignUp.IdleCornerRadius = 20;
            this.btn_SignUp.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_SignUp.IdleForecolor = System.Drawing.Color.White;
            this.btn_SignUp.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_SignUp.Location = new System.Drawing.Point(413, 507);
            this.btn_SignUp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_SignUp.Name = "btn_SignUp";
            this.btn_SignUp.Size = new System.Drawing.Size(235, 37);
            this.btn_SignUp.TabIndex = 22;
            this.btn_SignUp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_SignUp.Click += new System.EventHandler(this.btn_SignUp_Click);
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(305, 198);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(80, 27);
            this.bunifuCustomLabel7.TabIndex = 23;
            this.bunifuCustomLabel7.Text = "User Id";
            // 
            // txtbx_UserId
            // 
            this.txtbx_UserId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_UserId.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_UserId.ForeColor = System.Drawing.Color.White;
            this.txtbx_UserId.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_UserId.HintText = "";
            this.txtbx_UserId.isPassword = false;
            this.txtbx_UserId.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_UserId.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_UserId.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_UserId.LineThickness = 3;
            this.txtbx_UserId.Location = new System.Drawing.Point(443, 181);
            this.txtbx_UserId.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_UserId.Name = "txtbx_UserId";
            this.txtbx_UserId.Size = new System.Drawing.Size(289, 44);
            this.txtbx_UserId.TabIndex = 24;
            this.txtbx_UserId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UsersControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.txtbx_UserId);
            this.Controls.Add(this.bunifuCustomLabel7);
            this.Controls.Add(this.btn_SignUp);
            this.Controls.Add(this.txtbx_FirstName);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtbx_Password);
            this.Controls.Add(this.txtbx_Confirm);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.txtbx_UserName);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.txtbx_LastName);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Name = "UsersControl";
            this.Size = new System.Drawing.Size(1027, 589);
            this.Load += new System.EventHandler(this.UsersControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_LastName;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_UserName;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Confirm;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Password;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_FirstName;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_SignUp;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_UserId;
    }
}
