﻿namespace CarSaleAutomationV2._0
{
    partial class PurchaseControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PurchaseControl));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.cmbbx_Year = new Bunifu.Framework.UI.BunifuDropdown();
            this.cmbbx_Month = new Bunifu.Framework.UI.BunifuDropdown();
            this.txtbx_CustomerId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_Search = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.DataGridVehicles = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.btn_AddToCart = new Bunifu.Framework.UI.BunifuThinButton2();
            this.DataGridCart = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.btn_Purchase = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_ClearCart = new Bunifu.Framework.UI.BunifuThinButton2();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridVehicles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridCart)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(3, 0);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(140, 34);
            this.bunifuCustomLabel6.TabIndex = 21;
            this.bunifuCustomLabel6.Text = "Purchase";
            // 
            // cmbbx_Year
            // 
            this.cmbbx_Year.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Year.BorderRadius = 3;
            this.cmbbx_Year.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Year.Items = new string[] {
        "2018",
        "2019",
        "2020",
        "2021",
        "2022",
        "2023",
        "2024",
        "2025"};
            this.cmbbx_Year.Location = new System.Drawing.Point(237, 71);
            this.cmbbx_Year.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Year.Name = "cmbbx_Year";
            this.cmbbx_Year.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Year.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Year.selectedIndex = 0;
            this.cmbbx_Year.Size = new System.Drawing.Size(161, 34);
            this.cmbbx_Year.TabIndex = 22;
            // 
            // cmbbx_Month
            // 
            this.cmbbx_Month.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Month.BorderRadius = 3;
            this.cmbbx_Month.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Month.Items = new string[] {
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"};
            this.cmbbx_Month.Location = new System.Drawing.Point(406, 71);
            this.cmbbx_Month.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Month.Name = "cmbbx_Month";
            this.cmbbx_Month.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Month.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Month.selectedIndex = 0;
            this.cmbbx_Month.Size = new System.Drawing.Size(161, 34);
            this.cmbbx_Month.TabIndex = 23;
            // 
            // txtbx_CustomerId
            // 
            this.txtbx_CustomerId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_CustomerId.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_CustomerId.ForeColor = System.Drawing.Color.White;
            this.txtbx_CustomerId.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_CustomerId.HintText = "index";
            this.txtbx_CustomerId.isPassword = false;
            this.txtbx_CustomerId.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_CustomerId.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_CustomerId.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_CustomerId.LineThickness = 3;
            this.txtbx_CustomerId.Location = new System.Drawing.Point(30, 61);
            this.txtbx_CustomerId.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_CustomerId.Name = "txtbx_CustomerId";
            this.txtbx_CustomerId.Size = new System.Drawing.Size(170, 44);
            this.txtbx_CustomerId.TabIndex = 24;
            this.txtbx_CustomerId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_Search
            // 
            this.txtbx_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Search.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtbx_Search.ForeColor = System.Drawing.Color.White;
            this.txtbx_Search.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Search.HintText = "model";
            this.txtbx_Search.isPassword = false;
            this.txtbx_Search.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Search.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Search.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Search.LineThickness = 3;
            this.txtbx_Search.Location = new System.Drawing.Point(28, 127);
            this.txtbx_Search.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Search.Name = "txtbx_Search";
            this.txtbx_Search.Size = new System.Drawing.Size(235, 44);
            this.txtbx_Search.TabIndex = 25;
            this.txtbx_Search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_Search.OnValueChanged += new System.EventHandler(this.txtbx_Search_OnValueChanged);
            // 
            // DataGridVehicles
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DataGridVehicles.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridVehicles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridVehicles.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.DataGridVehicles.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridVehicles.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridVehicles.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridVehicles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridVehicles.DoubleBuffered = true;
            this.DataGridVehicles.EnableHeadersVisualStyles = false;
            this.DataGridVehicles.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.DataGridVehicles.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.DataGridVehicles.HeaderForeColor = System.Drawing.Color.White;
            this.DataGridVehicles.Location = new System.Drawing.Point(23, 178);
            this.DataGridVehicles.Name = "DataGridVehicles";
            this.DataGridVehicles.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DataGridVehicles.RowHeadersWidth = 51;
            this.DataGridVehicles.RowTemplate.Height = 24;
            this.DataGridVehicles.Size = new System.Drawing.Size(982, 150);
            this.DataGridVehicles.TabIndex = 26;
            this.DataGridVehicles.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGridVehicles_RowHeaderMouseClick);
            // 
            // btn_AddToCart
            // 
            this.btn_AddToCart.ActiveBorderThickness = 1;
            this.btn_AddToCart.ActiveCornerRadius = 20;
            this.btn_AddToCart.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_AddToCart.ActiveForecolor = System.Drawing.Color.White;
            this.btn_AddToCart.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_AddToCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_AddToCart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_AddToCart.BackgroundImage")));
            this.btn_AddToCart.ButtonText = "Add to cart";
            this.btn_AddToCart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_AddToCart.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddToCart.ForeColor = System.Drawing.Color.White;
            this.btn_AddToCart.IdleBorderThickness = 1;
            this.btn_AddToCart.IdleCornerRadius = 20;
            this.btn_AddToCart.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_AddToCart.IdleForecolor = System.Drawing.Color.White;
            this.btn_AddToCart.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_AddToCart.Location = new System.Drawing.Point(770, 336);
            this.btn_AddToCart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_AddToCart.Name = "btn_AddToCart";
            this.btn_AddToCart.Size = new System.Drawing.Size(235, 37);
            this.btn_AddToCart.TabIndex = 27;
            this.btn_AddToCart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_AddToCart.Click += new System.EventHandler(this.btn_AddToCart_Click);
            // 
            // DataGridCart
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DataGridCart.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.DataGridCart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridCart.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.DataGridCart.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridCart.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridCart.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DataGridCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridCart.DoubleBuffered = true;
            this.DataGridCart.EnableHeadersVisualStyles = false;
            this.DataGridCart.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.DataGridCart.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.DataGridCart.HeaderForeColor = System.Drawing.Color.White;
            this.DataGridCart.Location = new System.Drawing.Point(23, 381);
            this.DataGridCart.Name = "DataGridCart";
            this.DataGridCart.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DataGridCart.RowHeadersWidth = 51;
            this.DataGridCart.RowTemplate.Height = 24;
            this.DataGridCart.Size = new System.Drawing.Size(982, 150);
            this.DataGridCart.TabIndex = 28;
            this.DataGridCart.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGridVehicles_RowHeaderMouseClick);
            // 
            // btn_Purchase
            // 
            this.btn_Purchase.ActiveBorderThickness = 1;
            this.btn_Purchase.ActiveCornerRadius = 20;
            this.btn_Purchase.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Purchase.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Purchase.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Purchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Purchase.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Purchase.BackgroundImage")));
            this.btn_Purchase.ButtonText = "Purchase";
            this.btn_Purchase.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Purchase.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Purchase.ForeColor = System.Drawing.Color.White;
            this.btn_Purchase.IdleBorderThickness = 1;
            this.btn_Purchase.IdleCornerRadius = 20;
            this.btn_Purchase.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Purchase.IdleForecolor = System.Drawing.Color.White;
            this.btn_Purchase.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Purchase.Location = new System.Drawing.Point(770, 539);
            this.btn_Purchase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Purchase.Name = "btn_Purchase";
            this.btn_Purchase.Size = new System.Drawing.Size(235, 37);
            this.btn_Purchase.TabIndex = 29;
            this.btn_Purchase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Purchase.Click += new System.EventHandler(this.btn_Purchase_Click);
            // 
            // btn_ClearCart
            // 
            this.btn_ClearCart.ActiveBorderThickness = 1;
            this.btn_ClearCart.ActiveCornerRadius = 20;
            this.btn_ClearCart.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_ClearCart.ActiveForecolor = System.Drawing.Color.White;
            this.btn_ClearCart.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_ClearCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_ClearCart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_ClearCart.BackgroundImage")));
            this.btn_ClearCart.ButtonText = "Clear cart";
            this.btn_ClearCart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ClearCart.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ClearCart.ForeColor = System.Drawing.Color.White;
            this.btn_ClearCart.IdleBorderThickness = 1;
            this.btn_ClearCart.IdleCornerRadius = 20;
            this.btn_ClearCart.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_ClearCart.IdleForecolor = System.Drawing.Color.White;
            this.btn_ClearCart.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_ClearCart.Location = new System.Drawing.Point(527, 539);
            this.btn_ClearCart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_ClearCart.Name = "btn_ClearCart";
            this.btn_ClearCart.Size = new System.Drawing.Size(235, 37);
            this.btn_ClearCart.TabIndex = 30;
            this.btn_ClearCart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_ClearCart.Click += new System.EventHandler(this.btn_ClearCart_Click);
            // 
            // PurchaseControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.btn_ClearCart);
            this.Controls.Add(this.btn_Purchase);
            this.Controls.Add(this.DataGridCart);
            this.Controls.Add(this.btn_AddToCart);
            this.Controls.Add(this.DataGridVehicles);
            this.Controls.Add(this.txtbx_Search);
            this.Controls.Add(this.txtbx_CustomerId);
            this.Controls.Add(this.cmbbx_Month);
            this.Controls.Add(this.cmbbx_Year);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Name = "PurchaseControl";
            this.Size = new System.Drawing.Size(1027, 589);
            this.Load += new System.EventHandler(this.PurchaseControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridVehicles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridCart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Year;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Month;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_CustomerId;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Search;
        private Bunifu.Framework.UI.BunifuCustomDataGrid DataGridVehicles;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_AddToCart;
        private Bunifu.Framework.UI.BunifuCustomDataGrid DataGridCart;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Purchase;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_ClearCart;
    }
}
