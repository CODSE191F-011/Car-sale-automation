﻿namespace CarSaleAutomationV2._0
{
    partial class SalesControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.DataGridViewSales = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Search = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewSales)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(3, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(83, 34);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Sales";
            // 
            // DataGridViewSales
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DataGridViewSales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridViewSales.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridViewSales.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DataGridViewSales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridViewSales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridViewSales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridViewSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewSales.DoubleBuffered = true;
            this.DataGridViewSales.EnableHeadersVisualStyles = false;
            this.DataGridViewSales.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.DataGridViewSales.HeaderForeColor = System.Drawing.Color.White;
            this.DataGridViewSales.Location = new System.Drawing.Point(43, 164);
            this.DataGridViewSales.Name = "DataGridViewSales";
            this.DataGridViewSales.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DataGridViewSales.RowHeadersWidth = 51;
            this.DataGridViewSales.RowTemplate.Height = 24;
            this.DataGridViewSales.Size = new System.Drawing.Size(927, 376);
            this.DataGridViewSales.TabIndex = 1;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(38, 103);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(76, 27);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "Search";
            // 
            // txtbx_Search
            // 
            this.txtbx_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Search.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Search.ForeColor = System.Drawing.Color.White;
            this.txtbx_Search.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Search.HintText = "";
            this.txtbx_Search.isPassword = false;
            this.txtbx_Search.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Search.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Search.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Search.LineThickness = 3;
            this.txtbx_Search.Location = new System.Drawing.Point(189, 82);
            this.txtbx_Search.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Search.Name = "txtbx_Search";
            this.txtbx_Search.Size = new System.Drawing.Size(370, 48);
            this.txtbx_Search.TabIndex = 3;
            this.txtbx_Search.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtbx_Search.OnValueChanged += new System.EventHandler(this.txtbx_Search_OnValueChanged);
            // 
            // SalesControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.txtbx_Search);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.DataGridViewSales);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Name = "SalesControl";
            this.Size = new System.Drawing.Size(1027, 589);
            this.Load += new System.EventHandler(this.SalesControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewSales)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomDataGrid DataGridViewSales;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Search;
    }
}
