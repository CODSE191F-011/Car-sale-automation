﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSaleAutomationV2._0
{
    public partial class SalesControl : UserControl
    {
        public SalesControl()
        {
            InitializeComponent();
        }
        Database db = new Database();

        private void SalesControl_Load(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT CustomerId,VehicleId,SoldYear,SoldMonth,Seller FROM SALES";
                DataGridViewSales.DataSource = db.GetData(query);
            }
            catch(Exception)
            {
                MessageBox.Show("Cannot Load", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtbx_Search_OnValueChanged(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT CustomerId,VehicleId,SoldYear,SoldMonth,Seller FROM Sales WHERE CustomerId LIKE '{txtbx_Search.Text}%'  OR VehicleId LIKE '{txtbx_Search.Text}%' OR SoldYear LIKE '{txtbx_Search.Text}%' OR SoldMonth LIKE '{txtbx_Search.Text}%' OR Seller LIKE '{txtbx_Search.Text}%' ";
                DataGridViewSales.DataSource = db.GetData(query);
            }
            catch(Exception)
            {
                MessageBox.Show("Cannot Load", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
    }
}
