﻿namespace CarSaleAutomationV2._0
{
    partial class ExpensesControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExpensesControl));
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_TelephoneBill = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_WaterBill = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_ElectricityBill = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_Cleaning = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_OtherExpenses = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btn_Save = new Bunifu.Framework.UI.BunifuThinButton2();
            this.cmbbx_Month = new Bunifu.Framework.UI.BunifuDropdown();
            this.cmbbx_Year = new Bunifu.Framework.UI.BunifuDropdown();
            this.btn_Clear = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_View = new Bunifu.Framework.UI.BunifuThinButton2();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(3, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(137, 34);
            this.bunifuCustomLabel1.TabIndex = 2;
            this.bunifuCustomLabel1.Text = "Expenses";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CarSaleAutomationV2._0.Properties.Resources.cash;
            this.pictureBox1.Location = new System.Drawing.Point(482, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(111, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(277, 220);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(145, 27);
            this.bunifuCustomLabel8.TabIndex = 33;
            this.bunifuCustomLabel8.Text = "Telephone Bill";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(277, 274);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(103, 27);
            this.bunifuCustomLabel2.TabIndex = 34;
            this.bunifuCustomLabel2.Text = "Water Bill";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(277, 326);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(136, 27);
            this.bunifuCustomLabel3.TabIndex = 35;
            this.bunifuCustomLabel3.Text = "Electricity Bill";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(277, 378);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(94, 27);
            this.bunifuCustomLabel4.TabIndex = 36;
            this.bunifuCustomLabel4.Text = "Cleaning";
            // 
            // txtbx_TelephoneBill
            // 
            this.txtbx_TelephoneBill.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_TelephoneBill.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_TelephoneBill.ForeColor = System.Drawing.Color.White;
            this.txtbx_TelephoneBill.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_TelephoneBill.HintText = "";
            this.txtbx_TelephoneBill.isPassword = false;
            this.txtbx_TelephoneBill.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_TelephoneBill.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_TelephoneBill.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_TelephoneBill.LineThickness = 3;
            this.txtbx_TelephoneBill.Location = new System.Drawing.Point(461, 203);
            this.txtbx_TelephoneBill.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_TelephoneBill.Name = "txtbx_TelephoneBill";
            this.txtbx_TelephoneBill.Size = new System.Drawing.Size(289, 44);
            this.txtbx_TelephoneBill.TabIndex = 37;
            this.txtbx_TelephoneBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_WaterBill
            // 
            this.txtbx_WaterBill.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_WaterBill.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_WaterBill.ForeColor = System.Drawing.Color.White;
            this.txtbx_WaterBill.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_WaterBill.HintText = "";
            this.txtbx_WaterBill.isPassword = false;
            this.txtbx_WaterBill.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_WaterBill.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_WaterBill.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_WaterBill.LineThickness = 3;
            this.txtbx_WaterBill.Location = new System.Drawing.Point(461, 257);
            this.txtbx_WaterBill.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_WaterBill.Name = "txtbx_WaterBill";
            this.txtbx_WaterBill.Size = new System.Drawing.Size(289, 44);
            this.txtbx_WaterBill.TabIndex = 38;
            this.txtbx_WaterBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_ElectricityBill
            // 
            this.txtbx_ElectricityBill.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_ElectricityBill.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_ElectricityBill.ForeColor = System.Drawing.Color.White;
            this.txtbx_ElectricityBill.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_ElectricityBill.HintText = "";
            this.txtbx_ElectricityBill.isPassword = false;
            this.txtbx_ElectricityBill.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_ElectricityBill.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_ElectricityBill.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_ElectricityBill.LineThickness = 3;
            this.txtbx_ElectricityBill.Location = new System.Drawing.Point(461, 309);
            this.txtbx_ElectricityBill.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_ElectricityBill.Name = "txtbx_ElectricityBill";
            this.txtbx_ElectricityBill.Size = new System.Drawing.Size(289, 44);
            this.txtbx_ElectricityBill.TabIndex = 39;
            this.txtbx_ElectricityBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_Cleaning
            // 
            this.txtbx_Cleaning.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Cleaning.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Cleaning.ForeColor = System.Drawing.Color.White;
            this.txtbx_Cleaning.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Cleaning.HintText = "";
            this.txtbx_Cleaning.isPassword = false;
            this.txtbx_Cleaning.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Cleaning.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Cleaning.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Cleaning.LineThickness = 3;
            this.txtbx_Cleaning.Location = new System.Drawing.Point(461, 361);
            this.txtbx_Cleaning.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Cleaning.Name = "txtbx_Cleaning";
            this.txtbx_Cleaning.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Cleaning.TabIndex = 40;
            this.txtbx_Cleaning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_OtherExpenses
            // 
            this.txtbx_OtherExpenses.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_OtherExpenses.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_OtherExpenses.ForeColor = System.Drawing.Color.White;
            this.txtbx_OtherExpenses.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_OtherExpenses.HintText = "";
            this.txtbx_OtherExpenses.isPassword = false;
            this.txtbx_OtherExpenses.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_OtherExpenses.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_OtherExpenses.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_OtherExpenses.LineThickness = 3;
            this.txtbx_OtherExpenses.Location = new System.Drawing.Point(461, 413);
            this.txtbx_OtherExpenses.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_OtherExpenses.Name = "txtbx_OtherExpenses";
            this.txtbx_OtherExpenses.Size = new System.Drawing.Size(289, 44);
            this.txtbx_OtherExpenses.TabIndex = 41;
            this.txtbx_OtherExpenses.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(277, 430);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(158, 27);
            this.bunifuCustomLabel5.TabIndex = 42;
            this.bunifuCustomLabel5.Text = "Other Expenses";
            // 
            // btn_Save
            // 
            this.btn_Save.ActiveBorderThickness = 1;
            this.btn_Save.ActiveCornerRadius = 20;
            this.btn_Save.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Save.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Save.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Save.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Save.BackgroundImage")));
            this.btn_Save.ButtonText = "Save";
            this.btn_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Save.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.IdleBorderThickness = 1;
            this.btn_Save.IdleCornerRadius = 20;
            this.btn_Save.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Save.IdleForecolor = System.Drawing.Color.White;
            this.btn_Save.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Save.Location = new System.Drawing.Point(634, 490);
            this.btn_Save.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(116, 37);
            this.btn_Save.TabIndex = 46;
            this.btn_Save.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // cmbbx_Month
            // 
            this.cmbbx_Month.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Month.BorderRadius = 3;
            this.cmbbx_Month.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Month.Items = new string[] {
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"};
            this.cmbbx_Month.Location = new System.Drawing.Point(452, 148);
            this.cmbbx_Month.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Month.Name = "cmbbx_Month";
            this.cmbbx_Month.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Month.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Month.selectedIndex = 0;
            this.cmbbx_Month.Size = new System.Drawing.Size(161, 34);
            this.cmbbx_Month.TabIndex = 48;
            // 
            // cmbbx_Year
            // 
            this.cmbbx_Year.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Year.BorderRadius = 3;
            this.cmbbx_Year.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Year.Items = new string[] {
        "2018",
        "2019",
        "2020",
        "2021",
        "2022",
        "2023",
        "2024",
        "2025"};
            this.cmbbx_Year.Location = new System.Drawing.Point(283, 148);
            this.cmbbx_Year.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Year.Name = "cmbbx_Year";
            this.cmbbx_Year.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Year.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Year.selectedIndex = 0;
            this.cmbbx_Year.Size = new System.Drawing.Size(161, 34);
            this.cmbbx_Year.TabIndex = 47;
            // 
            // btn_Clear
            // 
            this.btn_Clear.ActiveBorderThickness = 1;
            this.btn_Clear.ActiveCornerRadius = 20;
            this.btn_Clear.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Clear.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Clear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Clear.BackgroundImage")));
            this.btn_Clear.ButtonText = "Clear";
            this.btn_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Clear.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.Color.White;
            this.btn_Clear.IdleBorderThickness = 1;
            this.btn_Clear.IdleCornerRadius = 20;
            this.btn_Clear.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Clear.IdleForecolor = System.Drawing.Color.White;
            this.btn_Clear.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.Location = new System.Drawing.Point(510, 490);
            this.btn_Clear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(116, 37);
            this.btn_Clear.TabIndex = 49;
            this.btn_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_View
            // 
            this.btn_View.ActiveBorderThickness = 1;
            this.btn_View.ActiveCornerRadius = 20;
            this.btn_View.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_View.ActiveForecolor = System.Drawing.Color.White;
            this.btn_View.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_View.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_View.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_View.BackgroundImage")));
            this.btn_View.ButtonText = "View";
            this.btn_View.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_View.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View.ForeColor = System.Drawing.Color.White;
            this.btn_View.IdleBorderThickness = 1;
            this.btn_View.IdleCornerRadius = 20;
            this.btn_View.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_View.IdleForecolor = System.Drawing.Color.White;
            this.btn_View.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_View.Location = new System.Drawing.Point(634, 148);
            this.btn_View.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_View.Name = "btn_View";
            this.btn_View.Size = new System.Drawing.Size(116, 37);
            this.btn_View.TabIndex = 50;
            this.btn_View.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_View.Click += new System.EventHandler(this.btn_View_Click);
            // 
            // ExpensesControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.btn_View);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.cmbbx_Month);
            this.Controls.Add(this.cmbbx_Year);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.txtbx_OtherExpenses);
            this.Controls.Add(this.txtbx_Cleaning);
            this.Controls.Add(this.txtbx_ElectricityBill);
            this.Controls.Add(this.txtbx_WaterBill);
            this.Controls.Add(this.txtbx_TelephoneBill);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel8);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Name = "ExpensesControl";
            this.Size = new System.Drawing.Size(1027, 589);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_TelephoneBill;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_WaterBill;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_ElectricityBill;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Cleaning;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_OtherExpenses;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Save;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Month;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Year;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Clear;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_View;
    }
}
