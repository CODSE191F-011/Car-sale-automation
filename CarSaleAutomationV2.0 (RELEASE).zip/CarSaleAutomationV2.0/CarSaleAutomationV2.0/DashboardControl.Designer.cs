﻿namespace CarSaleAutomationV2._0
{
    partial class DashboardControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardControl));
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator4 = new Bunifu.Framework.UI.BunifuSeparator();
            this.CartesianChartYearly = new LiveCharts.WinForms.CartesianChart();
            this.CartesianChartMonthly = new LiveCharts.WinForms.CartesianChart();
            this.cmbbx_Type = new Bunifu.Framework.UI.BunifuDropdown();
            this.ExpensesChart = new LiveCharts.WinForms.PieChart();
            this.cmbbx_Year = new Bunifu.Framework.UI.BunifuDropdown();
            this.cmbbx_Month = new Bunifu.Framework.UI.BunifuDropdown();
            this.btn_View = new Bunifu.Framework.UI.BunifuThinButton2();
            this.LabelOnPie1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.LabelOnPie2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(100, 10);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(78, 30);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "SALES";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(109, 305);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(123, 30);
            this.bunifuCustomLabel2.TabIndex = 1;
            this.bunifuCustomLabel2.Text = "EXPENSES";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(185, 4);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(757, 43);
            this.bunifuSeparator1.TabIndex = 2;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(4, 4);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(89, 43);
            this.bunifuSeparator2.TabIndex = 3;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(4, 300);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(98, 43);
            this.bunifuSeparator3.TabIndex = 4;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(239, 300);
            this.bunifuSeparator4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(703, 43);
            this.bunifuSeparator4.TabIndex = 5;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // CartesianChartYearly
            // 
            this.CartesianChartYearly.Location = new System.Drawing.Point(4, 63);
            this.CartesianChartYearly.Name = "CartesianChartYearly";
            this.CartesianChartYearly.Size = new System.Drawing.Size(524, 224);
            this.CartesianChartYearly.TabIndex = 6;
            this.CartesianChartYearly.Text = "Yearly";
            // 
            // CartesianChartMonthly
            // 
            this.CartesianChartMonthly.Location = new System.Drawing.Point(4, 63);
            this.CartesianChartMonthly.Name = "CartesianChartMonthly";
            this.CartesianChartMonthly.Size = new System.Drawing.Size(524, 224);
            this.CartesianChartMonthly.TabIndex = 8;
            this.CartesianChartMonthly.Text = "Yearly";
            // 
            // cmbbx_Type
            // 
            this.cmbbx_Type.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Type.BorderRadius = 3;
            this.cmbbx_Type.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Type.Items = new string[] {
        "Yearly",
        "Monthly"};
            this.cmbbx_Type.Location = new System.Drawing.Point(636, 63);
            this.cmbbx_Type.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Type.Name = "cmbbx_Type";
            this.cmbbx_Type.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Type.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Type.selectedIndex = 1;
            this.cmbbx_Type.Size = new System.Drawing.Size(289, 43);
            this.cmbbx_Type.TabIndex = 9;
            this.cmbbx_Type.onItemSelected += new System.EventHandler(this.cmbbx_Type_onItemSelected);
            // 
            // ExpensesChart
            // 
            this.ExpensesChart.ForeColor = System.Drawing.Color.White;
            this.ExpensesChart.Location = new System.Drawing.Point(25, 350);
            this.ExpensesChart.Name = "ExpensesChart";
            this.ExpensesChart.Size = new System.Drawing.Size(503, 236);
            this.ExpensesChart.TabIndex = 10;
            this.ExpensesChart.Text = "ExpensesChart";
            // 
            // cmbbx_Year
            // 
            this.cmbbx_Year.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Year.BorderRadius = 3;
            this.cmbbx_Year.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Year.Items = new string[] {
        "2018",
        "2019",
        "2020",
        "2021",
        "2022",
        "2023",
        "2024",
        "2025"};
            this.cmbbx_Year.Location = new System.Drawing.Point(574, 368);
            this.cmbbx_Year.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Year.Name = "cmbbx_Year";
            this.cmbbx_Year.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Year.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Year.selectedIndex = 0;
            this.cmbbx_Year.Size = new System.Drawing.Size(158, 31);
            this.cmbbx_Year.TabIndex = 11;
            // 
            // cmbbx_Month
            // 
            this.cmbbx_Month.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Month.BorderRadius = 3;
            this.cmbbx_Month.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Month.Items = new string[] {
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"};
            this.cmbbx_Month.Location = new System.Drawing.Point(767, 368);
            this.cmbbx_Month.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Month.Name = "cmbbx_Month";
            this.cmbbx_Month.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Month.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Month.selectedIndex = 0;
            this.cmbbx_Month.Size = new System.Drawing.Size(158, 31);
            this.cmbbx_Month.TabIndex = 12;
            // 
            // btn_View
            // 
            this.btn_View.ActiveBorderThickness = 1;
            this.btn_View.ActiveCornerRadius = 20;
            this.btn_View.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_View.ActiveForecolor = System.Drawing.Color.White;
            this.btn_View.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_View.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_View.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_View.BackgroundImage")));
            this.btn_View.ButtonText = "View";
            this.btn_View.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_View.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn_View.IdleBorderThickness = 1;
            this.btn_View.IdleCornerRadius = 20;
            this.btn_View.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_View.IdleForecolor = System.Drawing.Color.White;
            this.btn_View.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_View.Location = new System.Drawing.Point(652, 408);
            this.btn_View.Margin = new System.Windows.Forms.Padding(5);
            this.btn_View.Name = "btn_View";
            this.btn_View.Size = new System.Drawing.Size(181, 41);
            this.btn_View.TabIndex = 13;
            this.btn_View.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_View.Click += new System.EventHandler(this.btn_View_Click);
            // 
            // LabelOnPie1
            // 
            this.LabelOnPie1.AutoSize = true;
            this.LabelOnPie1.Font = new System.Drawing.Font("Dense", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelOnPie1.ForeColor = System.Drawing.Color.White;
            this.LabelOnPie1.Location = new System.Drawing.Point(159, 408);
            this.LabelOnPie1.Name = "LabelOnPie1";
            this.LabelOnPie1.Size = new System.Drawing.Size(232, 40);
            this.LabelOnPie1.TabIndex = 14;
            this.LabelOnPie1.Text = "Select Year and Month";
            // 
            // LabelOnPie2
            // 
            this.LabelOnPie2.AutoSize = true;
            this.LabelOnPie2.Font = new System.Drawing.Font("Dense", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelOnPie2.ForeColor = System.Drawing.Color.White;
            this.LabelOnPie2.Location = new System.Drawing.Point(195, 458);
            this.LabelOnPie2.Name = "LabelOnPie2";
            this.LabelOnPie2.Size = new System.Drawing.Size(152, 40);
            this.LabelOnPie2.TabIndex = 15;
            this.LabelOnPie2.Text = "and click View";
            // 
            // DashboardControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.LabelOnPie2);
            this.Controls.Add(this.LabelOnPie1);
            this.Controls.Add(this.btn_View);
            this.Controls.Add(this.cmbbx_Month);
            this.Controls.Add(this.cmbbx_Year);
            this.Controls.Add(this.ExpensesChart);
            this.Controls.Add(this.cmbbx_Type);
            this.Controls.Add(this.CartesianChartMonthly);
            this.Controls.Add(this.CartesianChartYearly);
            this.Controls.Add(this.bunifuSeparator4);
            this.Controls.Add(this.bunifuSeparator3);
            this.Controls.Add(this.bunifuSeparator2);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Name = "DashboardControl";
            this.Size = new System.Drawing.Size(1027, 589);
            this.Load += new System.EventHandler(this.DashboardControl_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator4;
        private LiveCharts.WinForms.CartesianChart CartesianChartYearly;
        private LiveCharts.WinForms.CartesianChart CartesianChartMonthly;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Type;
        private LiveCharts.WinForms.PieChart ExpensesChart;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Year;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Month;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_View;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelOnPie1;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelOnPie2;
    }
}
