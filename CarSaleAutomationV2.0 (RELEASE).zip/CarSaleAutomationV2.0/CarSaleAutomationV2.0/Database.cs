﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;

namespace CarSaleAutomationV2._0
{
    class Database
    {
        private SqlConnection con;
        private SqlCommand cmd;
        private SqlDataAdapter adp;
        private SqlDataReader reader;

        public Database()
        {
            con = new SqlConnection("Data Source=MSI;Initial Catalog=CarSaleAutomation;Integrated Security=True");
        }

        public void OpenConnection()
        {
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        public int Save_Update_Delete(string query)
        {
            OpenConnection();
            cmd = new SqlCommand(query, con);
            int i = cmd.ExecuteNonQuery();
            CloseConnection();
            return i;
        }

        public DataTable GetData(string query)
        {
            OpenConnection();
            adp = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            CloseConnection();
            return dt;
        }

        public SqlDataReader ReadData(string query)
        {
            OpenConnection();
            cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            //CLoseConnection();
            return reader;
        }

        public string NextId(string query)
        {
            string nextid;
            OpenConnection();
            cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            if (!reader.HasRows)
            {
                CloseConnection();
                return nextid = "empty";
            }
            else
            {
                Regex re = new Regex(@"([a-zA-Z]+)(\d+)");
                Match result = re.Match(reader[0].ToString());
                string alphaPart = result.Groups[1].Value;
                int numberPart = Convert.ToInt32(result.Groups[2].Value);
                nextid = (alphaPart + (numberPart + 1)).ToString();
                CloseConnection();
            }
            return nextid;
        }

        public string GetUserId(string query)
        {
            string userid;
            OpenConnection();
            cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            userid = reader[0].ToString();
            CloseConnection();
            return userid;

        }

        public string GetLoggedInUser()
        {
            string currentUser;
            OpenConnection();
            cmd = new SqlCommand("SELECT Userid FROM LoggedInUser", con);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            currentUser = reader[0].ToString();
            CloseConnection();
            return currentUser;
        }
    }
}
