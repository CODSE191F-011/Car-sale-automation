﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using WinFormCharpWebCam;
using System.Data.SqlClient;

namespace CarSaleAutomationV2._0
{
    public partial class CustomerControl : UserControl
    {
        WebCam webcam;
        Database db = new Database();
        Imaging imaging = new Imaging();
        public CustomerControl()
        {
            InitializeComponent();
        }

        private void CustomerControl_Load(object sender, EventArgs e)
        {
            string query = $"SELECT CustomerId FROM Customers WHERE CustomerNo = (SELECT TOP 1 CustomerNo FROM Customers ORDER BY CustomerNo DESC);";
            try
            {
                if (db.NextId(query) == "empty")
                {
                    txtbx_Index.Text = "C1";
                }
                else
                {
                    txtbx_Index.Text = db.NextId(query);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("No data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Camera_Click(object sender, EventArgs e)
        {
            //webcam.Stop();
            webcam = new WebCam();
            webcam.InitializeWebCam(ref CameraImage);
            DefaultImage.Visible = false;
            CapturedImage.Visible = false;
            CameraImage.Visible = true;
            webcam.Start();
        }

        private void btn_Capture_Click(object sender, EventArgs e)
        {
            Image img = CameraImage.Image;
            img.RotateFlip(RotateFlipType.RotateNoneFlipX);
            CapturedImage.Image = img;
            //CapturedPhoto.Image = CameraPhoto.Image;
            DefaultImage.Visible = false;
            CameraImage.Visible = false;
            CapturedImage.Visible = true;
            try
            {
                webcam.Stop();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Please Turn on the camera", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }          
        }

        private void btn_Browse_Click(object sender, EventArgs e)
        {
            try
            {
                DefaultImage.Visible = false;
                CameraImage.Visible = false;
                CapturedImage.Visible = true;
                openFileDialog.ShowDialog();
                CapturedImage.Image = Image.FromFile(openFileDialog.FileName);
            }
            catch (OutOfMemoryException)
            {
                MessageBox.Show("Please select images only", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Please select an image", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtbx_Index.Text))
            {
                MessageBox.Show("Index cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_FirstName.Text))
            {
                MessageBox.Show("First name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_FirstName.Text.Any(char.IsDigit))
            {
                MessageBox.Show("First name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_LastName.Text))
            {
                MessageBox.Show("Last name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_LastName.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Last name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_ContactNo.Text))
            {
                MessageBox.Show("Contact No cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_ContactNo.Text.Length != 10 || txtbx_ContactNo.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Contact No must contains 10 numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (DatePicker_DOB.Value == null)
            {
                MessageBox.Show("Please give your date of birth", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (cmbbx_Gender.selectedIndex == -1)
            {
                MessageBox.Show("Please select your gender", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Address.Text))
            {
                MessageBox.Show("Address cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    string currentUser = db.GetLoggedInUser();
                    string arr = imaging.ImageToBase64(CapturedImage.Image, System.Drawing.Imaging.ImageFormat.Jpeg);
                    string query = $"INSERT INTO Customers VALUES ('{txtbx_Index.Text}','{txtbx_FirstName.Text}','{txtbx_LastName.Text}','{txtbx_ContactNo.Text}','{DatePicker_DOB.Value}','{cmbbx_Gender.selectedValue}','{txtbx_Address.Text}','{arr}','{currentUser}')";
                    int i = db.Save_Update_Delete(query);
                    if (i == 1)
                    {
                        MessageBox.Show("Data saved successfully", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtbx_FirstName.Text = "";
                        txtbx_LastName.Text = "";
                        txtbx_ContactNo.Text = "";
                        txtbx_Address.Text = "";
                        cmbbx_Gender.selectedIndex = -1;
                        CameraImage.Visible = false;
                        CapturedImage.Visible = false;
                        DefaultImage.Visible = true;
                        string query2 = $"SELECT CustomerId FROM Customers WHERE CustomerNo = (SELECT TOP 1 CustomerNo FROM Customers ORDER BY CustomerNo DESC);";
                        try
                        {
                            txtbx_Index.Text = db.NextId(query2);
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("No Data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot save data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException)
                {
                    MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtbx_Index.Text))
            {
                MessageBox.Show("Index cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_FirstName.Text))
            {
                MessageBox.Show("First name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_FirstName.Text.Any(char.IsDigit))
            {
                MessageBox.Show("First name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_LastName.Text))
            {
                MessageBox.Show("Last name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_LastName.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Last name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_ContactNo.Text))
            {
                MessageBox.Show("Contact No cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_ContactNo.Text.Length != 10 || txtbx_ContactNo.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Contact No must contains 10 numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (DatePicker_DOB.Value == null)
            {
                MessageBox.Show("Please give your date of birth", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (cmbbx_Gender.selectedIndex == -1)
            {
                MessageBox.Show("Please select your gender", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_Address.Text))
            {
                MessageBox.Show("Address cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    string arr = imaging.ImageToBase64(CapturedImage.Image, System.Drawing.Imaging.ImageFormat.Jpeg);
                    string query = $"UPDATE Customers SET FirstName = '{txtbx_FirstName.Text}',LastName = '{txtbx_LastName.Text}',ContactNo = '{txtbx_ContactNo.Text}',DOB = '{DatePicker_DOB.Value}',Gender = '{cmbbx_Gender.selectedValue}',Address = '{txtbx_Address.Text}',Photo = '{arr}' WHERE CustomerId = '{txtbx_Index.Text}'";
                    int i = db.Save_Update_Delete(query);
                    if (i == 1)
                    {
                        MessageBox.Show("Data updated successfully", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtbx_FirstName.Text = "";
                        txtbx_LastName.Text = "";
                        txtbx_ContactNo.Text = "";
                        txtbx_Address.Text = "";
                        cmbbx_Gender.selectedIndex = -1;
                        CameraImage.Visible = false;
                        CapturedImage.Visible = false;
                        DefaultImage.Visible = true;
                        txtbx_Search.Text = "";
                        string query2 = $"SELECT CustomerId FROM Customers WHERE CustomerNo = (SELECT TOP 1 CustomerNo FROM Customers ORDER BY CustomerNo DESC);";
                        try
                        {
                            txtbx_Index.Text = db.NextId(query2);
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("No records", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot update data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException)
                {
                    MessageBox.Show("Cannot update data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            try
            {
                //string arr = imaging.ImageToBase64(CapturedImage.Image, System.Drawing.Imaging.ImageFormat.Jpeg);
                string query = $"DELETE FROM Customers WHERE CustomerId = '{txtbx_Index.Text}'";
                int i = db.Save_Update_Delete(query);
                if (i == 1)
                {
                    MessageBox.Show("Data removed", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtbx_FirstName.Text = "";
                    txtbx_LastName.Text = "";
                    txtbx_ContactNo.Text = "";
                    txtbx_Address.Text = "";
                    cmbbx_Gender.selectedIndex = -1;
                    CameraImage.Visible = false;
                    CapturedImage.Visible = false;
                    DefaultImage.Visible = true;
                    txtbx_Search.Text = "";
                    string query2 = $"SELECT CustomerId FROM Customers WHERE CustomerNo = (SELECT TOP 1 CustomerNo FROM Customers ORDER BY CustomerNo DESC);";
                    try
                    {
                        txtbx_Index.Text = db.NextId(query2);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("No records", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Cannot remove data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Cannot remove data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txtbx_Search.Text = "";
            txtbx_FirstName.Text = "";
            txtbx_LastName.Text = "";
            txtbx_ContactNo.Text = "";
            txtbx_Address.Text = "";
            cmbbx_Gender.selectedIndex = -1;
            CameraImage.Visible = false;
            CapturedImage.Visible = false;
            DefaultImage.Visible = true;
            string query2 = $"SELECT CustomerId FROM Customers WHERE CustomerNo = (SELECT TOP 1 CustomerNo FROM Customers ORDER BY CustomerNo DESC);";
            try
            {
                if (db.NextId(query2) == "empty")
                {
                    txtbx_Index.Text = "C1";
                }
                else
                {
                    txtbx_Index.Text = db.NextId(query2);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("No records", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT * FROM Customers WHERE CustomerId = '{txtbx_Search.Text}'";
                SqlDataReader reader = db.ReadData(query);
                if (reader.HasRows)
                {
                    txtbx_Index.Text = reader[1].ToString();
                    txtbx_FirstName.Text = reader[2].ToString();
                    txtbx_LastName.Text = reader[3].ToString();
                    txtbx_ContactNo.Text = reader[4].ToString();
                    DatePicker_DOB.Value = (DateTime)(reader[5]);
                    if (reader[6].ToString() == "Male")
                    {
                        cmbbx_Gender.selectedIndex = 0;
                    }
                    else if (reader[6].ToString() == "Female")
                    {
                        cmbbx_Gender.selectedIndex = 1;
                    }
                    txtbx_Address.Text = reader[7].ToString();
                    DefaultImage.Visible = false;
                    CameraImage.Visible = false;
                    CapturedImage.Visible = true;
                    CapturedImage.Image = imaging.Base64ToImage(reader[8].ToString());
                    db.CloseConnection();
                }
                else
                {
                    MessageBox.Show("No data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    db.CloseConnection();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                db.CloseConnection();
            }
        }
    }
}
