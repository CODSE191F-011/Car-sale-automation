﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSaleAutomationV2._0
{
    public partial class UsersControl : UserControl
    {
        Database db = new Database();
        public UsersControl()
        {
            InitializeComponent();
        }

        private void btn_SignUp_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtbx_FirstName.Text))
            {
                MessageBox.Show("First name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_FirstName.Text.Any(char.IsDigit))
            {
                MessageBox.Show("First name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_LastName.Text))
            {
                MessageBox.Show("Last name cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_LastName.Text.Any(char.IsDigit))
            {
                MessageBox.Show("Last name cannot have numbers", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (String.IsNullOrEmpty(txtbx_UserName.Text))
            {
                MessageBox.Show("Username cannot be empty", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Password.Text.Length == 0)
            {
                MessageBox.Show("Please enter your password", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Confirm.Text.Length == 0)
            {
                MessageBox.Show("Please confirm the password", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Confirm.Text != txtbx_Password.Text)
            {
                MessageBox.Show("Confirmed password is not the entered Password", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    string query = $"INSERT INTO Users VALUES ('{txtbx_UserId.Text}','{txtbx_FirstName.Text}','{txtbx_LastName.Text}')";
                    int i = db.Save_Update_Delete(query);
                    if (i == 1)
                    {
                        string query2 = $"INSERT INTO Logins VALUES ('{txtbx_UserId.Text}','{txtbx_UserName.Text}','{txtbx_Password.Text}')";
                        int j = db.Save_Update_Delete(query2);
                        MessageBox.Show("Signed Up", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtbx_FirstName.Text = "";
                        txtbx_LastName.Text = "";
                        txtbx_UserName.Text = "";
                        txtbx_Password.Text = "1";
                        txtbx_Confirm.Text = "1";
                        string query3 = $"SELECT UserId FROM Users WHERE UserNo = (SELECT TOP 1 UserNo FROM Users ORDER BY UserNo DESC);";
                        try
                        {
                            txtbx_UserId.Text = db.NextId(query3);
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("Please Check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sign Up failed", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException)
                {
                    MessageBox.Show("Please Check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please Check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void UsersControl_Load(object sender, EventArgs e)
        {
            string query = $"SELECT UserId FROM Users WHERE UserNo = (SELECT TOP 1 UserNo FROM Users ORDER BY UserNo DESC);";

            try
            {
                if (db.NextId(query) == "empty")
                {
                    txtbx_UserId.Text = "U1";
                }
                else
                {
                    txtbx_UserId.Text = db.NextId(query);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please Check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
