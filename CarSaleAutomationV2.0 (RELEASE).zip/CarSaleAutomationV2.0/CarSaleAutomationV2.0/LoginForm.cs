﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSaleAutomationV2._0
{
    public partial class LoginForm : Form
    {
        Database db = new Database();
        public LoginForm()
        {
            InitializeComponent();
        }

        Point lastPoint;

        private void MainPanel_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void MainPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_LogIn_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT Password FROM Logins WHERE UserName = '{txtbx_UserName.Text}'";
                SqlDataReader reader = db.ReadData(query);
                if (reader.HasRows)
                {
                    if (reader[0].ToString() == txtbx_Password.Text)
                    {
                        db.CloseConnection();
                        string query2 = $"SELECT UserId FROM Logins WHERE UserName = '{txtbx_UserName.Text}'";
                        string userid = db.GetUserId(query2);
                        db.CloseConnection();
                        string query3 = $"INSERT INTO LoggedInUser VALUES('{userid}')";
                        db.Save_Update_Delete(query3);
                        this.Hide();
                        Form1 obj = new Form1();
                        obj.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Password,Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        db.CloseConnection();
                    }
                }
                else
                {
                    MessageBox.Show("Incorrect Username, Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    db.CloseConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.ToString(), "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                db.CloseConnection();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                db.CloseConnection();
            }
        }
    }
}
