﻿namespace CarSaleAutomationV2._0
{
    partial class CustomerControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerControl));
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_FirstName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_LastName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_ContactNo = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtbx_Address = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.DatePicker_DOB = new Bunifu.Framework.UI.BunifuDatepicker();
            this.cmbbx_Gender = new Bunifu.Framework.UI.BunifuDropdown();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtbx_Index = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.CameraImage = new System.Windows.Forms.PictureBox();
            this.btn_Update = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Clear = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Remove = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Add = new Bunifu.Framework.UI.BunifuThinButton2();
            this.CapturedImage = new System.Windows.Forms.PictureBox();
            this.btn_Camera = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Capture = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_Browse = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtbx_Search = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_Search = new Bunifu.Framework.UI.BunifuThinButton2();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.DefaultImage = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.CameraImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CapturedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DefaultImage)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(3, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(157, 34);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Customers";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(130, 213);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(115, 27);
            this.bunifuCustomLabel2.TabIndex = 1;
            this.bunifuCustomLabel2.Text = "First Name";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(131, 265);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(112, 27);
            this.bunifuCustomLabel3.TabIndex = 2;
            this.bunifuCustomLabel3.Text = "Last Name";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(131, 317);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(120, 27);
            this.bunifuCustomLabel4.TabIndex = 3;
            this.bunifuCustomLabel4.Text = "Contact No";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(131, 369);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(56, 27);
            this.bunifuCustomLabel5.TabIndex = 4;
            this.bunifuCustomLabel5.Text = "DOB";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(131, 421);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(82, 27);
            this.bunifuCustomLabel6.TabIndex = 5;
            this.bunifuCustomLabel6.Text = "Gender";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(131, 472);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(89, 27);
            this.bunifuCustomLabel7.TabIndex = 6;
            this.bunifuCustomLabel7.Text = "Address";
            // 
            // txtbx_FirstName
            // 
            this.txtbx_FirstName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_FirstName.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_FirstName.ForeColor = System.Drawing.Color.White;
            this.txtbx_FirstName.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_FirstName.HintText = "";
            this.txtbx_FirstName.isPassword = false;
            this.txtbx_FirstName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_FirstName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_FirstName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_FirstName.LineThickness = 3;
            this.txtbx_FirstName.Location = new System.Drawing.Point(315, 196);
            this.txtbx_FirstName.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_FirstName.Name = "txtbx_FirstName";
            this.txtbx_FirstName.Size = new System.Drawing.Size(289, 44);
            this.txtbx_FirstName.TabIndex = 7;
            this.txtbx_FirstName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_LastName
            // 
            this.txtbx_LastName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_LastName.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_LastName.ForeColor = System.Drawing.Color.White;
            this.txtbx_LastName.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_LastName.HintText = "";
            this.txtbx_LastName.isPassword = false;
            this.txtbx_LastName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_LastName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_LastName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_LastName.LineThickness = 3;
            this.txtbx_LastName.Location = new System.Drawing.Point(315, 248);
            this.txtbx_LastName.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_LastName.Name = "txtbx_LastName";
            this.txtbx_LastName.Size = new System.Drawing.Size(289, 44);
            this.txtbx_LastName.TabIndex = 8;
            this.txtbx_LastName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_ContactNo
            // 
            this.txtbx_ContactNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_ContactNo.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_ContactNo.ForeColor = System.Drawing.Color.White;
            this.txtbx_ContactNo.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_ContactNo.HintText = "";
            this.txtbx_ContactNo.isPassword = false;
            this.txtbx_ContactNo.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_ContactNo.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_ContactNo.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_ContactNo.LineThickness = 3;
            this.txtbx_ContactNo.Location = new System.Drawing.Point(315, 300);
            this.txtbx_ContactNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_ContactNo.Name = "txtbx_ContactNo";
            this.txtbx_ContactNo.Size = new System.Drawing.Size(289, 44);
            this.txtbx_ContactNo.TabIndex = 9;
            this.txtbx_ContactNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbx_Address
            // 
            this.txtbx_Address.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Address.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Address.ForeColor = System.Drawing.Color.White;
            this.txtbx_Address.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Address.HintText = "";
            this.txtbx_Address.isPassword = false;
            this.txtbx_Address.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Address.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Address.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Address.LineThickness = 3;
            this.txtbx_Address.Location = new System.Drawing.Point(315, 455);
            this.txtbx_Address.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Address.Name = "txtbx_Address";
            this.txtbx_Address.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Address.TabIndex = 10;
            this.txtbx_Address.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DatePicker_DOB
            // 
            this.DatePicker_DOB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.DatePicker_DOB.BorderRadius = 0;
            this.DatePicker_DOB.ForeColor = System.Drawing.Color.White;
            this.DatePicker_DOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DatePicker_DOB.FormatCustom = null;
            this.DatePicker_DOB.Location = new System.Drawing.Point(315, 352);
            this.DatePicker_DOB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DatePicker_DOB.Name = "DatePicker_DOB";
            this.DatePicker_DOB.Size = new System.Drawing.Size(289, 44);
            this.DatePicker_DOB.TabIndex = 11;
            this.DatePicker_DOB.Value = new System.DateTime(2019, 11, 16, 14, 1, 47, 694);
            // 
            // cmbbx_Gender
            // 
            this.cmbbx_Gender.BackColor = System.Drawing.Color.Transparent;
            this.cmbbx_Gender.BorderRadius = 3;
            this.cmbbx_Gender.ForeColor = System.Drawing.Color.White;
            this.cmbbx_Gender.Items = new string[] {
        "Male",
        "Female"};
            this.cmbbx_Gender.Location = new System.Drawing.Point(315, 404);
            this.cmbbx_Gender.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbbx_Gender.Name = "cmbbx_Gender";
            this.cmbbx_Gender.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(119)))), ((int)(((byte)(128)))));
            this.cmbbx_Gender.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.cmbbx_Gender.selectedIndex = -1;
            this.cmbbx_Gender.Size = new System.Drawing.Size(289, 43);
            this.cmbbx_Gender.TabIndex = 12;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(131, 161);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(64, 27);
            this.bunifuCustomLabel8.TabIndex = 13;
            this.bunifuCustomLabel8.Text = "Index";
            // 
            // txtbx_Index
            // 
            this.txtbx_Index.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Index.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Index.ForeColor = System.Drawing.Color.White;
            this.txtbx_Index.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Index.HintText = "";
            this.txtbx_Index.isPassword = false;
            this.txtbx_Index.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Index.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Index.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Index.LineThickness = 3;
            this.txtbx_Index.Location = new System.Drawing.Point(315, 144);
            this.txtbx_Index.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Index.Name = "txtbx_Index";
            this.txtbx_Index.Size = new System.Drawing.Size(289, 44);
            this.txtbx_Index.TabIndex = 14;
            this.txtbx_Index.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CameraImage
            // 
            this.CameraImage.Image = global::CarSaleAutomationV2._0.Properties.Resources.Camera;
            this.CameraImage.Location = new System.Drawing.Point(696, 75);
            this.CameraImage.Name = "CameraImage";
            this.CameraImage.Size = new System.Drawing.Size(235, 227);
            this.CameraImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CameraImage.TabIndex = 19;
            this.CameraImage.TabStop = false;
            // 
            // btn_Update
            // 
            this.btn_Update.ActiveBorderThickness = 1;
            this.btn_Update.ActiveCornerRadius = 20;
            this.btn_Update.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Update.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Update.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Update.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Update.BackgroundImage")));
            this.btn_Update.ButtonText = "Update";
            this.btn_Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Update.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.IdleBorderThickness = 1;
            this.btn_Update.IdleCornerRadius = 20;
            this.btn_Update.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Update.IdleForecolor = System.Drawing.Color.White;
            this.btn_Update.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Update.Location = new System.Drawing.Point(818, 420);
            this.btn_Update.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(116, 37);
            this.btn_Update.TabIndex = 18;
            this.btn_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.ActiveBorderThickness = 1;
            this.btn_Clear.ActiveCornerRadius = 20;
            this.btn_Clear.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Clear.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Clear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Clear.BackgroundImage")));
            this.btn_Clear.ButtonText = "Clear";
            this.btn_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Clear.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.Color.White;
            this.btn_Clear.IdleBorderThickness = 1;
            this.btn_Clear.IdleCornerRadius = 20;
            this.btn_Clear.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Clear.IdleForecolor = System.Drawing.Color.White;
            this.btn_Clear.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Clear.Location = new System.Drawing.Point(818, 467);
            this.btn_Clear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(116, 37);
            this.btn_Clear.TabIndex = 17;
            this.btn_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Remove
            // 
            this.btn_Remove.ActiveBorderThickness = 1;
            this.btn_Remove.ActiveCornerRadius = 20;
            this.btn_Remove.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Remove.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Remove.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Remove.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Remove.BackgroundImage")));
            this.btn_Remove.ButtonText = "Remove";
            this.btn_Remove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Remove.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Remove.ForeColor = System.Drawing.Color.White;
            this.btn_Remove.IdleBorderThickness = 1;
            this.btn_Remove.IdleCornerRadius = 20;
            this.btn_Remove.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Remove.IdleForecolor = System.Drawing.Color.White;
            this.btn_Remove.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Remove.Location = new System.Drawing.Point(696, 467);
            this.btn_Remove.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(116, 37);
            this.btn_Remove.TabIndex = 16;
            this.btn_Remove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.ActiveBorderThickness = 1;
            this.btn_Add.ActiveCornerRadius = 20;
            this.btn_Add.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Add.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Add.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Add.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Add.BackgroundImage")));
            this.btn_Add.ButtonText = "Add";
            this.btn_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Add.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.ForeColor = System.Drawing.Color.White;
            this.btn_Add.IdleBorderThickness = 1;
            this.btn_Add.IdleCornerRadius = 20;
            this.btn_Add.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Add.IdleForecolor = System.Drawing.Color.White;
            this.btn_Add.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Add.Location = new System.Drawing.Point(696, 420);
            this.btn_Add.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(116, 37);
            this.btn_Add.TabIndex = 15;
            this.btn_Add.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // CapturedImage
            // 
            this.CapturedImage.Image = global::CarSaleAutomationV2._0.Properties.Resources.Camera;
            this.CapturedImage.Location = new System.Drawing.Point(696, 75);
            this.CapturedImage.Name = "CapturedImage";
            this.CapturedImage.Size = new System.Drawing.Size(235, 227);
            this.CapturedImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CapturedImage.TabIndex = 20;
            this.CapturedImage.TabStop = false;
            // 
            // btn_Camera
            // 
            this.btn_Camera.ActiveBorderThickness = 1;
            this.btn_Camera.ActiveCornerRadius = 20;
            this.btn_Camera.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Camera.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Camera.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Camera.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Camera.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Camera.BackgroundImage")));
            this.btn_Camera.ButtonText = "Camera";
            this.btn_Camera.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Camera.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Camera.ForeColor = System.Drawing.Color.White;
            this.btn_Camera.IdleBorderThickness = 1;
            this.btn_Camera.IdleCornerRadius = 20;
            this.btn_Camera.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Camera.IdleForecolor = System.Drawing.Color.White;
            this.btn_Camera.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Camera.Location = new System.Drawing.Point(696, 310);
            this.btn_Camera.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Camera.Name = "btn_Camera";
            this.btn_Camera.Size = new System.Drawing.Size(235, 37);
            this.btn_Camera.TabIndex = 21;
            this.btn_Camera.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Camera.Click += new System.EventHandler(this.btn_Camera_Click);
            // 
            // btn_Capture
            // 
            this.btn_Capture.ActiveBorderThickness = 1;
            this.btn_Capture.ActiveCornerRadius = 20;
            this.btn_Capture.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Capture.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Capture.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Capture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Capture.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Capture.BackgroundImage")));
            this.btn_Capture.ButtonText = "Capture";
            this.btn_Capture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Capture.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Capture.ForeColor = System.Drawing.Color.White;
            this.btn_Capture.IdleBorderThickness = 1;
            this.btn_Capture.IdleCornerRadius = 20;
            this.btn_Capture.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Capture.IdleForecolor = System.Drawing.Color.White;
            this.btn_Capture.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Capture.Location = new System.Drawing.Point(696, 357);
            this.btn_Capture.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Capture.Name = "btn_Capture";
            this.btn_Capture.Size = new System.Drawing.Size(116, 37);
            this.btn_Capture.TabIndex = 22;
            this.btn_Capture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Capture.Click += new System.EventHandler(this.btn_Capture_Click);
            // 
            // btn_Browse
            // 
            this.btn_Browse.ActiveBorderThickness = 1;
            this.btn_Browse.ActiveCornerRadius = 20;
            this.btn_Browse.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Browse.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Browse.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Browse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Browse.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Browse.BackgroundImage")));
            this.btn_Browse.ButtonText = "Browse";
            this.btn_Browse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Browse.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse.ForeColor = System.Drawing.Color.White;
            this.btn_Browse.IdleBorderThickness = 1;
            this.btn_Browse.IdleCornerRadius = 20;
            this.btn_Browse.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Browse.IdleForecolor = System.Drawing.Color.White;
            this.btn_Browse.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Browse.Location = new System.Drawing.Point(818, 357);
            this.btn_Browse.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Browse.Name = "btn_Browse";
            this.btn_Browse.Size = new System.Drawing.Size(116, 37);
            this.btn_Browse.TabIndex = 23;
            this.btn_Browse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Browse.Click += new System.EventHandler(this.btn_Browse_Click);
            // 
            // txtbx_Search
            // 
            this.txtbx_Search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbx_Search.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Search.ForeColor = System.Drawing.Color.White;
            this.txtbx_Search.HintForeColor = System.Drawing.Color.Empty;
            this.txtbx_Search.HintText = "index";
            this.txtbx_Search.isPassword = false;
            this.txtbx_Search.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtbx_Search.LineIdleColor = System.Drawing.Color.Gray;
            this.txtbx_Search.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtbx_Search.LineThickness = 3;
            this.txtbx_Search.Location = new System.Drawing.Point(82, 64);
            this.txtbx_Search.Margin = new System.Windows.Forms.Padding(4);
            this.txtbx_Search.Name = "txtbx_Search";
            this.txtbx_Search.Size = new System.Drawing.Size(225, 44);
            this.txtbx_Search.TabIndex = 24;
            this.txtbx_Search.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Search
            // 
            this.btn_Search.ActiveBorderThickness = 1;
            this.btn_Search.ActiveCornerRadius = 20;
            this.btn_Search.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Search.ActiveForecolor = System.Drawing.Color.White;
            this.btn_Search.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Search.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Search.BackgroundImage")));
            this.btn_Search.ButtonText = "Search";
            this.btn_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Search.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.White;
            this.btn_Search.IdleBorderThickness = 1;
            this.btn_Search.IdleCornerRadius = 20;
            this.btn_Search.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.btn_Search.IdleForecolor = System.Drawing.Color.White;
            this.btn_Search.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(128)))), ((int)(((byte)(242)))));
            this.btn_Search.Location = new System.Drawing.Point(315, 64);
            this.btn_Search.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(116, 37);
            this.btn_Search.TabIndex = 25;
            this.btn_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // DefaultImage
            // 
            this.DefaultImage.Image = global::CarSaleAutomationV2._0.Properties.Resources.Camera;
            this.DefaultImage.Location = new System.Drawing.Point(696, 75);
            this.DefaultImage.Name = "DefaultImage";
            this.DefaultImage.Size = new System.Drawing.Size(235, 227);
            this.DefaultImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DefaultImage.TabIndex = 26;
            this.DefaultImage.TabStop = false;
            // 
            // CustomerControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.Controls.Add(this.DefaultImage);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.txtbx_Search);
            this.Controls.Add(this.btn_Browse);
            this.Controls.Add(this.btn_Capture);
            this.Controls.Add(this.btn_Camera);
            this.Controls.Add(this.CapturedImage);
            this.Controls.Add(this.CameraImage);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txtbx_Index);
            this.Controls.Add(this.bunifuCustomLabel8);
            this.Controls.Add(this.cmbbx_Gender);
            this.Controls.Add(this.DatePicker_DOB);
            this.Controls.Add(this.txtbx_Address);
            this.Controls.Add(this.txtbx_ContactNo);
            this.Controls.Add(this.txtbx_LastName);
            this.Controls.Add(this.txtbx_FirstName);
            this.Controls.Add(this.bunifuCustomLabel7);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Name = "CustomerControl";
            this.Size = new System.Drawing.Size(1027, 589);
            this.Load += new System.EventHandler(this.CustomerControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CameraImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CapturedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DefaultImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_FirstName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_LastName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_ContactNo;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Address;
        private Bunifu.Framework.UI.BunifuDatepicker DatePicker_DOB;
        private Bunifu.Framework.UI.BunifuDropdown cmbbx_Gender;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Index;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Add;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Remove;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Clear;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Update;
        private System.Windows.Forms.PictureBox CameraImage;
        private System.Windows.Forms.PictureBox CapturedImage;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Camera;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Capture;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Browse;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtbx_Search;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Search;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.PictureBox DefaultImage;
    }
}
