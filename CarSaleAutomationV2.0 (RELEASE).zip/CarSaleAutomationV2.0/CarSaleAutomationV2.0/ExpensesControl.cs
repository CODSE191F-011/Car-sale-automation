﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSaleAutomationV2._0
{
    public partial class ExpensesControl : UserControl
    {
        Database db = new Database();
        public ExpensesControl()
        {
            InitializeComponent();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtbx_TelephoneBill.Text))
            {
                MessageBox.Show("Telephone Bill cannot be empty or give 0", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_TelephoneBill.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Telephone Bill cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (string.IsNullOrEmpty(txtbx_WaterBill.Text))
            {
                MessageBox.Show("Water Bill cannot be empty or give 0", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_WaterBill.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Water Bill cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (string.IsNullOrEmpty(txtbx_ElectricityBill.Text))
            {
                MessageBox.Show("Electricity Bill cannot be empty or give 0", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_ElectricityBill.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Electricity Bill cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (string.IsNullOrEmpty(txtbx_Cleaning.Text))
            {
                MessageBox.Show("Cleaning Expenses cannot be empty or give 0", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_Cleaning.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Cleaning Expenses cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (string.IsNullOrEmpty(txtbx_OtherExpenses.Text))
            {
                MessageBox.Show("Other Expenses cannot be empty or give 0", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtbx_OtherExpenses.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Other Expenses cannot have letters", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    string query = $"SELECT * FROM Expenses WHERE Year = '{cmbbx_Year.selectedValue}' AND Month = '{cmbbx_Month.selectedIndex + 1}'";
                    SqlDataReader reader = db.ReadData(query);
                    if (reader.HasRows)
                    {
                        MessageBox.Show("The data is already there", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        db.CloseConnection();
                    }
                    else
                    {
                        db.CloseConnection();
                        string currentUser = db.GetLoggedInUser();
                        string query2 = $"INSERT INTO Expenses VALUES ('{cmbbx_Year.selectedValue}','{cmbbx_Month.selectedIndex + 1}','{txtbx_TelephoneBill.Text}','{txtbx_WaterBill.Text}','{txtbx_ElectricityBill.Text}','{txtbx_Cleaning.Text}','{txtbx_OtherExpenses.Text}','{currentUser}')";
                        int i = db.Save_Update_Delete(query2);
                        if (i == 1)
                        {
                            MessageBox.Show("Data Saved", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtbx_TelephoneBill.Text = "";
                            txtbx_WaterBill.Text = "";
                            txtbx_ElectricityBill.Text = "";
                            txtbx_Cleaning.Text = "";
                            txtbx_OtherExpenses.Text = "";
                            cmbbx_Year.selectedIndex = 0;
                            cmbbx_Month.selectedIndex = 0;
                        }
                        else
                        {
                            MessageBox.Show("Cannot Save", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        db.CloseConnection();
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Please try again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txtbx_TelephoneBill.Text = "";
            txtbx_WaterBill.Text = "";
            txtbx_ElectricityBill.Text = "";
            txtbx_Cleaning.Text = "";
            txtbx_OtherExpenses.Text = "";
            cmbbx_Year.selectedIndex = 0;
            cmbbx_Month.selectedIndex = 0;
        }

        private void btn_View_Click(object sender, EventArgs e)
        {
            try
            {
                string query = $"SELECT * FROM Expenses WHERE Year = '{cmbbx_Year.selectedValue}' AND Month = '{cmbbx_Month.selectedIndex + 1}'";
                SqlDataReader reader = db.ReadData(query);
                if (reader.HasRows)
                {
                    txtbx_TelephoneBill.Text = reader[3].ToString(); ;
                    txtbx_WaterBill.Text = reader[4].ToString();
                    txtbx_ElectricityBill.Text = reader[5].ToString();
                    txtbx_Cleaning.Text = reader[6].ToString();
                    txtbx_OtherExpenses.Text = reader[7].ToString();
                    db.CloseConnection();
                }
                else
                {
                    MessageBox.Show("No Data", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    db.CloseConnection();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Car Sale Automation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                db.CloseConnection();
            }
        }
    }
}
